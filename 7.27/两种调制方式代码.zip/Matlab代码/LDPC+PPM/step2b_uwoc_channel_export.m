%% 步骤2b：水下光信道仿真（衰减+AWGN）并导出 EasyWave CSV（如果用这个就不需要运行step3）
% 按你的确认：
%   1) 加在 step2 的 ppm_signal 上
%   2) 杰罗夫I、100m：alpha = exp(-cL) ≈ 0.0136（近似无多径）
%   3) AWGN，SNR = 10 dB（相对衰减后信号 alpha*s 的功率）
%   4) 光强截断 >= 0
%   5) 暂不做湍流
%   6) 导出方案B：接收端等效增益 G=1/alpha，使无噪时高电平回到约1V，再上仪器
%
% 模型：
%   y = max(alpha * s + n, 0)
%   z = max(G * y, 0) = max(s + n/alpha, 0)   % 方案B，SNR保持不变

clear; clc;
rng(42);    % 固定噪声种子，结果可复现；要换一次噪声就改这个数

%% 1. 读取 PPM 波形
if ~exist('step2_result.mat', 'file')
    error('未找到 step2_result.mat，请先运行 step2_ppm_modulate.m');
end
load('step2_result.mat', 'ppm_signal', 'samples_per_symbol', 'samples_per_slot', 'Ns');

s = ppm_signal(:).';          % 0/1 基带

%% 2. 信道参数
alpha = 0.0136;                % e^{-cL}，杰罗夫I、100m
SNR_dB = 5;                   % 你指定的SNR
G = 1 / alpha;                 % 方案B：等效接收放大，把无噪峰值拉回约1
V_high = 1;                    % 导出目标高电平约1V

% --- 衰减 ---
s_att = alpha * s;

% --- 按衰减后信号功率定义AWGN ---
Ps = mean(s_att.^2);           % 信号功率
SNR_lin = 10^(SNR_dB/10);
Pn = Ps / SNR_lin;             % 噪声功率
n = sqrt(Pn) * randn(size(s_att));

% --- 加噪 + 光强非负截断 ---
y = max(s_att + n, 0);         % 物理接收端（衰减后）

% --- 方案B：等效放大到约1V量级，再截断负值 ---
z = max(G * y, 0);             % 上仪器用的波形（无噪时脉冲≈1）

% 实际SNR核对（用未截断前的线性量，更接近定义）
snr_check_dB = 10*log10(mean(s_att.^2) / mean(n.^2));

fprintf('===== 水下光信道仿真 =====\n');
fprintf('alpha = %.6f, SNR设定 = %.1f dB, 实测SNR(加截断前) = %.2f dB\n', ...
    alpha, SNR_dB, snr_check_dB);
fprintf('衰减后峰值约 = %.4f, 方案B放大后无噪峰值约 = %.2f\n', alpha, alpha*G);
fprintf('z: min=%.3f, max=%.3f, mean=%.3f\n', min(z), max(z), mean(z));

%% 3. 导出前400个符号到 EasyWave CSV（仪器16k点限制）
N_sym_export = 400;
if N_sym_export > Ns
    error('请求导出%d符号，但只有%d符号。', N_sym_export, Ns);
end

N_pts = N_sym_export * samples_per_symbol;   % 16000
T_slot = 1e-6;
dt = T_slot / samples_per_slot;              % 0.1 us
fs = 1 / dt;
wave = z(1:N_pts);                           % 已是方案B后的电压波形

% 为避免个别噪声尖峰过高，导出时轻微限幅到 [0, 1.5]V（不影响主脉冲≈1V）
wave = min(max(wave, 0), 1.5);

T_period = N_pts * dt;
freq_hz = 1 / T_period;
amp_hdr = max(V_high, max(wave));
offset_hdr = 0;
phase_hdr = 0;
xpos = (0:N_pts-1) * dt;

out_name = sprintf('uwoc_jerlovI_100m_SNR%ddB_400sym_EasyWave.csv', SNR_dB);
fid = fopen(out_name, 'w');
if fid < 0
    error('无法创建: %s', out_name);
end
fprintf(fid, 'data length,%d\n', N_pts);
fprintf(fid, 'frequency,%.9f\n', freq_hz);
fprintf(fid, 'amp,%.9f\n', amp_hdr);
fprintf(fid, 'offset,%.9f\n', offset_hdr);
fprintf(fid, 'phase,%.9f\n', phase_hdr);
for k = 1:7
    fprintf(fid, ',\n');
end
fprintf(fid, 'xpos,value\n');
for i = 1:N_pts
    fprintf(fid, '%.6E,%.9f\n', xpos(i), wave(i));
end
fclose(fid);

fprintf('\n===== EasyWave CSV =====\n');
fprintf('文件: %s\n', out_name);
fprintf('点数=%d, 符号=%d, dt=%.3fus, fs=%.3fMSa/s\n', ...
    N_pts, N_sym_export, dt*1e6, fs/1e6);
fprintf('导出波形: min=%.3f V, max=%.3f V\n', min(wave), max(wave));

%% 4. 画对比图（前3个符号）
n_show = 3 * samples_per_symbol;
figure;
subplot(3,1,1);
stem(s(1:n_show), 'filled', 'MarkerSize', 2);
title('发送 PPM (s)'); ylabel('幅度'); grid on;
subplot(3,1,2);
plot(y(1:n_show));
title(sprintf('衰减+噪声后 y=max(alpha*s+n,0), alpha=%.4f, SNR=%ddB', alpha, SNR_dB));
ylabel('幅度'); grid on;
subplot(3,1,3);
plot(z(1:n_show));
title('方案B放大后 z（上仪器）'); xlabel('采样点'); ylabel('V'); grid on;

%% 5. 保存（整段z可供后续纯MATLAB解调/译码仿真）
save('step2b_uwoc_result.mat', 'alpha', 'SNR_dB', 'G', 's', 's_att', 'n', ...
     'y', 'z', 'wave', 'out_name', 'N_sym_export', 'N_pts', 'dt', 'fs', ...
     'snr_check_dB', 'samples_per_symbol', 'samples_per_slot', 'Ns');
disp('已保存: step2b_uwoc_result.mat');
