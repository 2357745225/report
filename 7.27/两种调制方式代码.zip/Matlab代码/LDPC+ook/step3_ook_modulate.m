%% step3_ook_modulate.m
% 步骤3：OOK 调制（二进制比特流 -> 基带光强波形）
%
% 【本步作用】
%   读取 step1b 的 coded_bits，加前导码后做 OOK 映射：
%     bit=0 -> 0 V（无光）
%     bit=1 -> amp V（有光，默认 1 V）
%   再按“每比特持若干采样点”拼成矩形基带波形，供步骤4 水下信道仿真。
%
% 【与旧 PAM 脚本的区别】
%   PAM：2 bit/符号、4 电平；OOK：1 bit/符号、2 电平（开/关）
%   本脚本为 OOK 重写，不再做 4-PAM 分组映射。
%
% 【不确定/可改参数 — 改后步骤4/5 须一致】
%   samples_per_symbol = 10   每比特采样点数（= 每 OOK 符号采样点）
%   amp = 1                     高电平幅度 (V)，低电平固定为 0
%   preamble_bits               前导码比特序列，接收端用于同步
%   ook_levels = [0, 1]         OOK 两电平（低/高），高电平再乘 amp
%
% 【输出】step3_result.mat（步骤4 读取 ppm_signal 等变量）

clear; clc;

%% 1. 读取步骤2（LDPC）编码结果
if ~exist('step1b_ldpc_result.mat', 'file')
    error('未找到 step1b_ldpc_result.mat，请先运行 step1b_ldpc_encode.m');
end
load('step1b_ldpc_result.mat', 'coded_bits');

%% 2. 前导码设计
% 重复 [1 1 0 0]：产生“高-高-低-低”方波，便于示波器/接收端找起始位置
% 与旧 PAM 脚本相同前导码，方便你对比两种调制方式
preamble_bits = repmat([1 1 0 0], 1, 16);   % 64 bit 前导码
fprintf('前导码长度: %d 比特 = %d 个 OOK 符号\n', ...
    length(preamble_bits), length(preamble_bits));

%% 3. 拼接前导码 + 数据
tx_bits = [preamble_bits, coded_bits];

%% 4. OOK 参数
M = 2;                          % OOK 等价于 2-PAM（开/关两态）
bits_per_symbol = 1;            % OOK：1 比特对应 1 个符号
samples_per_symbol = 10;        % 每符号（每比特）采样点数
samples_per_slot = samples_per_symbol;   % 与步骤4 CSV 的 dt 计算保持一致
amp = 1;                        % 高电平峰值 (V)
ook_levels = [0, 1];            % 索引1->0V, 索引2->1V（再乘 amp）

%% 5. 比特流整理（OOK 无需按 2/4 分组，仅保留与旧脚本同名变量）
Nb = length(tx_bits);
pad_len = mod(bits_per_symbol - mod(Nb, bits_per_symbol), bits_per_symbol);
bit_padded = [tx_bits, zeros(1, pad_len)];   % OOK 下 pad_len 恒为 0
Ns = length(bit_padded) / bits_per_symbol;

% bit_groups：每行 1 个比特（Ns×1），保留变量名供步骤5 可能使用
bit_groups = bit_padded(:);

% pulse_val：符号电平索引，0->索引1(0V)，1->索引2(1V)
pulse_val = bit_groups + 1;

%% 6. 生成 OOK 基带矩形波形
% 每个符号时段内幅度恒定（非载波 OOK，适合 UWOC 光强开/关模型）
ook_signal = zeros(1, Ns * samples_per_symbol);
for k = 1:Ns
    idx = (k-1)*samples_per_symbol + (1:samples_per_symbol);
    ook_signal(idx) = amp * ook_levels(pulse_val(k));
end

% ppm_signal：步骤4 信道脚本沿用的变量名（含义为“基带调制波形”）
ppm_signal = ook_signal;

%% 7. 核对示例（前 16 个比特）
fprintf('\n===== OOK 核对示例（前16比特）=====\n');
fprintf('映射规则: bit=0 -> 0V, bit=1 -> %.1fV\n', amp);
n_show = min(16, Ns);
for k = 1:n_show
    if k <= length(preamble_bits)
        label = ' [前导码]';
    else
        label = ' [数据]';
    end
    b = bit_groups(k);
    fprintf('符号%2d | 比特: %d | 幅度: %.1fV%s\n', ...
        k, b, amp * ook_levels(pulse_val(k)), label);
end

fprintf('\n原始编码比特数 = %d\n', length(coded_bits));
fprintf('前导码比特数 = %d\n', length(preamble_bits));
fprintf('总比特数(含前导+补零) = %d\n', length(bit_padded));
fprintf('OOK 符号数 Ns = %d\n', Ns);
fprintf('每符号采样点 = %d\n', samples_per_symbol);
fprintf('OOK 信号总长度 = %d\n', length(ook_signal));

% 符号率 / 采样率（步骤4 导出 CSV 会用到 dt）
T_slot = 1e-6;                              % 每符号时长 1 us（可改，须与步骤4 一致）
dt = T_slot / samples_per_slot;             % 采样间隔
fs = 1 / dt;
fprintf('符号率 = %.0f ksym/s, 采样率 fs = %.1f MSa/s, dt = %.2f us\n', ...
    1/T_slot/1e3, fs/1e6, dt*1e6);

%% 8. 波形图（前 6 个符号 = 60 个采样点）
figure;
stem(ook_signal(1:min(60, length(ook_signal))), 'filled', 'MarkerSize', 3);
xlabel('采样点');
ylabel('幅度 (V)');
title('OOK 基带波形（前6符号，含前导码开头）');
grid on;
xlim([0, min(60, length(ook_signal))]);

%% 9. 诊断信息
fprintf('\n===== 诊断信息 =====\n');
fprintf('pulse_val 取值范围: [%d, %d] (OOK 应为 1~2)\n', min(pulse_val), max(pulse_val));
fprintf('前导码对应前8符号比特: ');
fprintf('%d ', bit_groups(1:min(8, Ns)));
fprintf('(应为 1 1 0 0 1 1 0 0)\n');
fprintf('波形峰值: %.3f V, 低电平: %.3f V\n', max(ook_signal), min(ook_signal));

%% 10. 内置校验
preamble_ok = isequal(bit_groups(1:length(preamble_bits)), preamble_bits(:));
data_ok = isequal(bit_groups(length(preamble_bits)+1:length(preamble_bits)+length(coded_bits)), coded_bits(:));
level_ok = all(ismember(unique(ook_signal), [0, amp]));
len_ok = (length(ook_signal) == Ns * samples_per_symbol);

fprintf('\n===== 内置校验 =====\n');
fprintf('前导码嵌入正确     : %s\n', string(preamble_ok));
fprintf('数据段比特一致       : %s\n', string(data_ok));
fprintf('波形仅含 0/amp 两电平: %s\n', string(level_ok));
fprintf('波形长度 = Ns*spb   : %s\n', string(len_ok));
if preamble_ok && data_ok && level_ok && len_ok
    fprintf('>> 全部校验通过，可进入步骤4 水下信道仿真。\n');
else
    warning('OOK 调制校验未全部通过，请检查参数。');
end

%% 11. 保存（步骤4 读 ppm_signal；步骤5 读前导码与采样参数）
save('step3_result.mat', ...
     'M', 'bits_per_symbol', 'samples_per_symbol', ...
     'samples_per_slot', 'amp', 'ook_levels', ...
     'bit_padded', 'pad_len', 'bit_groups', 'pulse_val', ...
     'ook_signal', 'ppm_signal', 'Ns', ...
     'preamble_bits', 'tx_bits', 'coded_bits', ...
     'T_slot', 'dt', 'fs');

fprintf('\n完成！step3_result.mat 已保存。\n');
