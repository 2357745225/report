%% 步骤1：文本 -> 十进制ASCII字节流 -> 8位二进制字节流
% 说明：
% 1) 整段文本按“字符”编码（数字、空格都各自占1个字节）
% 2) 例如 "10" 不是数值10，而是字符 '1' 和 '0' 两个ASCII

clear; clc;

%% 1. 原始文本
text_str = ['0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 ' ...
            '26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 ' ...
            '50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 ' ...
            '74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 ' ...
            '98 99'];

%% 2. 文本 -> 十进制ASCII码字节流
% double(字符) 或 uint8(字符) 都可得到ASCII十进制值
ascii_dec = double(text_str);   % 1 x N 的十进制ASCII数组

%% 3. 十进制ASCII -> 8位二进制字节流
% 每个ASCII十进制数字转成8位二进制（高位在前）
N = length(ascii_dec);
bin_mat = zeros(N, 8);          % 每行1个字节，共8位

for i = 1:N
    bin_mat(i, :) = bitget(ascii_dec(i), 8:-1:1);
end

% 展平成一维二进制比特流（按字节顺序依次排列）
bin_stream = reshape(bin_mat.', 1, []);   % 1 x (N*8)

%% 4. 结果展示（先看前几个字符，便于核对）
disp('===== 核对示例（前10个字符）=====');
for i = 1:10
    fprintf('字符: ''%s'' | 十进制ASCII: %3d | 8位二进制: %s\n', ...
        text_str(i), ascii_dec(i), num2str(bin_mat(i, :)));
end

fprintf('\n总字符数 N = %d\n', N);
fprintf('十进制ASCII字节流长度 = %d\n', length(ascii_dec));
fprintf('二进制比特流长度 = %d (应等于 N*8 = %d)\n', length(bin_stream), N*8);

%% 5. 保存结果，供后续步骤使用
save('step1_result.mat', 'text_str', 'ascii_dec', 'bin_mat', 'bin_stream');
disp('已保存: step1_result.mat');
