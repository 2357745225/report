%% 步骤1b：二进制比特流 -> LDPC编码
% 参数（按你的设定）：
%   R = 1/2, N = 256, K = 128
%   规则 (3,6) 校验矩阵 H  （列重3，行重6）
%   信息比特不够K的整数倍时，末尾补0
%
% 码字形式（系统码）：c = [信息位(K) , 校验位(N-K)]
% 满足：mod(H * c.', 2) = 0

clear; clc;
rng(1);    % 固定随机种子，保证每次生成的H可复现（译码时必须用同一张H）

%% 1. 读取步骤1信息比特
if ~exist('step1_result.mat', 'file')
    error('未找到 step1_result.mat，请先运行 step1_ascii_encode.m');
end
load('step1_result.mat', 'bin_stream');

%% 2. LDPC 参数
N = 256;                 % 码长
K = 128;                 % 信息位长
Mparity = N - K;         % 校验位数 = 128
R = K / N;               % 码率 = 1/2
wc = 3;                  % 列重
wr = 6;                  % 行重

% 度数检查：M*wr 应等于 N*wc
if Mparity * wr ~= N * wc
    error('规则LDPC度数不匹配：请检查 N,K,wc,wr');
end

%% 3. 构造规则 (3,6) 校验矩阵 H (Mparity x N)
H = local_make_regular_H(N, Mparity, wc, wr);

% 统计度数，确认基本规则
col_w = sum(H, 1);
row_w = sum(H, 2);
fprintf('===== LDPC参数 =====\n');
fprintf('N=%d, K=%d, R=%.3f, H大小=%dx%d\n', N, K, R, Mparity, N);
fprintf('列重: min=%d max=%d mean=%.2f (目标%d)\n', min(col_w), max(col_w), mean(col_w), wc);
fprintf('行重: min=%d max=%d mean=%.2f (目标%d)\n', min(row_w), max(row_w), mean(row_w), wr);

%% 4. 把 H 整理成便于系统编码的形式
% 通过列交换，使右半部分对应校验位，并得到编码用矩阵 A
% 使得：parity = mod(A * info.', 2).'
% 码字：c = [info, parity]
[H_sys, A, col_perm] = local_make_systematic_encoder(H, K);

%% 5. 信息比特分块 + 末尾补0
Nb = length(bin_stream);
n_pad_info = mod(K - mod(Nb, K), K);          % 补到K的整数倍
info_padded = [bin_stream, zeros(1, n_pad_info)];
n_blocks = length(info_padded) / K;

fprintf('\n===== 分块 =====\n');
fprintf('原始信息比特 Nb = %d\n', Nb);
fprintf('信息补零 n_pad_info = %d\n', n_pad_info);
fprintf('码块数 n_blocks = %d\n', n_blocks);

%% 6. 逐块 LDPC 编码
coded_bits = zeros(1, n_blocks * N);
syndrome_ok = true(1, n_blocks);

for b = 1:n_blocks
    u = info_padded((b-1)*K + (1:K));         % 1 x K
    p = mod(A * u.', 2).';                   % 1 x Mparity  校验位
    c = [u, p];                               % 1 x N  系统码字
    coded_bits((b-1)*N + (1:N)) = c;

    % 校验：H_sys * c' == 0 (mod 2)
    s = mod(H_sys * c.', 2);
    syndrome_ok(b) = all(s == 0);
end

fprintf('\n===== 编码结果 =====\n');
fprintf('编码比特总数 = %d (= n_blocks * N)\n', length(coded_bits));
fprintf('所有码字校验 H*c=0 ? %s\n', string(all(syndrome_ok)));

% 抽查第1块
u1 = info_padded(1:K);
c1 = coded_bits(1:N);
fprintf('第1块: 信息位前16bit = %s\n', sprintf('%d', u1(1:16)));
fprintf('第1块: 码字前16bit   = %s (系统码应与信息位相同)\n', sprintf('%d', c1(1:16)));
fprintf('第1块: 校验位前16bit = %s\n', sprintf('%d', c1(K+1:K+16)));

%% 7. 保存（步骤2调制将使用 coded_bits；译码还需 H_sys/A 等）
save('step1b_ldpc_result.mat', 'N', 'K', 'R', 'wc', 'wr', 'H', 'H_sys', 'A', ...
     'col_perm', 'bin_stream', 'info_padded', 'n_pad_info', 'n_blocks', ...
     'coded_bits', 'syndrome_ok');
disp('已保存: step1b_ldpc_result.mat');

%% ===== 本地函数 =====
function H = local_make_regular_H(N, Mparity, wc, wr)
% 用“插座配对法”构造近似规则 (wc, wr) 的 H
% 变量节点各wc个插座，校验节点各wr个插座，随机配对

    n_edge = N * wc;                 % = Mparity * wr
    var_socks = kron(1:N, ones(1, wc));                 % 1 x n_edge
    chk_socks = kron(1:Mparity, ones(1, wr));           % 1 x n_edge
    chk_socks = chk_socks(randperm(n_edge));            % 随机打乱后配对

    H = zeros(Mparity, N);
    for e = 1:n_edge
        i = chk_socks(e);
        j = var_socks(e);
        H(i, j) = 1;                 % 重复边合并为1，可能轻微破坏严格规则性
    end

    % 若出现全0列/行，做一次简单修补（保证可编码）
    for j = 1:N
        if all(H(:, j) == 0)
            i = randi(Mparity);
            H(i, j) = 1;
        end
    end
    for i = 1:Mparity
        if all(H(i, :) == 0)
            j = randi(N);
            H(i, j) = 1;
        end
    end
end

function [H_sys, A, col_perm] = local_make_systematic_encoder(H, K)
% 选Mparity个线性无关列做校验位，其余K列做信息位
% 发送码字采用系统形式 c=[u,p]，使用 H_sys=[A,I] 作为工作校验矩阵
% （H_sys 与原H行等价+列重排后一致，初学链路直接用 H_sys 即可）

    [Mparity, N] = size(H);
    if K ~= N - Mparity
        error('K 必须等于 N - size(H,1)');
    end

    % ---- 对H做GF(2)消元，找出Mparity个主元列 ----
    Htmp = H;
    pivot_cols = zeros(1, Mparity);
    used = false(1, N);

    for row = 1:Mparity
        found = false;
        for c = 1:N
            if used(c), continue; end
            piv = find(Htmp(row:Mparity, c) == 1, 1, 'first');
            if isempty(piv), continue; end

            pr = row + piv - 1;
            if pr ~= row
                Htmp([row pr], :) = Htmp([pr row], :);
            end
            for r = 1:Mparity
                if r ~= row && Htmp(r, c) == 1
                    Htmp(r, :) = mod(Htmp(r, :) + Htmp(row, :), 2);
                end
            end
            pivot_cols(row) = c;
            used(c) = true;
            found = true;
            break;
        end
        if ~found
            error('H不满秩，无法系统编码。请修改 rng 种子后重跑。');
        end
    end

    info_cols = find(~used);
    if numel(info_cols) ~= K
        error('信息列数量不等于K，构造失败');
    end

    % 列顺序：信息位在前，校验主元列在后
    col_perm = [info_cols, pivot_cols];
    H_perm = H(:, col_perm);
    Hu = H_perm(:, 1:K);
    Hp = H_perm(:, K+1:N);

    Hp_inv = local_gf2_inv(Hp);
    A = mod(Hp_inv * Hu, 2);     % p' = A * u'
    H_sys = [A, eye(Mparity)];   % 工作用系统校验矩阵
end

function Minv = local_gf2_inv(M)
% GF(2) 方阵求逆（高斯-约当）
    n = size(M, 1);
    if size(M, 2) ~= n
        error('只能对方阵求逆');
    end
    Aug = [M, eye(n)];
    for col = 1:n
        piv = find(Aug(col:n, col) == 1, 1, 'first');
        if isempty(piv)
            error('校验子矩阵不可逆，请修改 rng 种子后重跑');
        end
        pr = col + piv - 1;
        if pr ~= col
            Aug([col pr], :) = Aug([pr col], :);
        end
        for r = 1:n
            if r ~= col && Aug(r, col) == 1
                Aug(r, :) = mod(Aug(r, :) + Aug(col, :), 2);
            end
        end
    end
    Minv = Aug(:, n+1:end);
end
