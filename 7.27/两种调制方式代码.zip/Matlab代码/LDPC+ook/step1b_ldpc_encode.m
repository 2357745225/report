%% step1b_ldpc_encode.m  （对应总流程的步骤2：二进制比特流 -> LDPC编码）
%
% 【本步作用】
%   读取 step1 的 bin_stream，分块后做 LDPC 系统编码，输出 coded_bits。
%
% 【不确定/可改参数 — 改后须与步骤5译码一致】
%   N=256, K=128, R=1/2   — 码长、信息位长、码率
%   wc=3, wr=6             — 规则矩阵目标列重/行重（实际 H 可能略有偏差，见下文）
%   rng(1)                 — 随机种子；H 矩阵由此决定，译码必须用同一张 H，勿改种子
%   n_pad_info             — 自动计算，信息位不足 K 整数倍时末尾补 0
%
% 【输出文件】step1b_ldpc_result.mat（步骤3 OOK、步骤5 译码都会 load）

clear; clc;
rng(1);    % 固定种子：保证 H 可复现；步骤5 必须 load 本文件里的 H_sys，不能重新生成

%% 1. 读取步骤1信息比特
if ~exist('step1_result.mat', 'file')
    error('未找到 step1_result.mat，请先运行 step1_ascii_encode.m');
end
load('step1_result.mat', 'bin_stream');

%% 2. LDPC 参数
N = 256;                 % 码长（每个码块的编码后比特数）
K = 128;                 % 信息位长（每个码块送入编码器的比特数）
Mparity = N - K;         % 校验位数 = 128
R = K / N;               % 码率 = 1/2
wc = 3;                  % 目标列重（每个变量节点连 3 条边）
wr = 6;                  % 目标行重（每个校验节点连 6 条边）

% 度数检查：M*wr 应等于 N*wc，否则无法构造规则矩阵
if Mparity * wr ~= N * wc
    error('规则LDPC度数不匹配：请检查 N,K,wc,wr');
end

%% 3. 构造规则 (3,6) 校验矩阵 H (Mparity x N)
% 用“插座配对法”随机连边；重复边合并为 1 时，实际列/行重可能略偏离 wc/wr
H = local_make_regular_H(N, Mparity, wc, wr);

col_w = sum(H, 1);
row_w = sum(H, 2);
fprintf('===== LDPC参数 =====\n');
fprintf('N=%d, K=%d, R=%.3f, H大小=%dx%d\n', N, K, R, Mparity, N);
fprintf('列重: min=%d max=%d mean=%.2f (目标%d)\n', min(col_w), max(col_w), mean(col_w), wc);
fprintf('行重: min=%d max=%d mean=%.2f (目标%d)\n', min(row_w), max(row_w), mean(row_w), wr);
if min(col_w) < wc || min(row_w) < wr
    fprintf('【说明】因重复边合并，H 仅为近似规则；对学习仿真可接受，不影响编码正确性。\n');
end

%% 4. 把 H 整理成系统编码形式
% 列重排后：码字 c = [信息位 u (K) , 校验位 p (Mparity)]
% 编码关系：p = mod(A * u'', 2)''，且 H_sys * c'' = 0 (mod 2)
[H_sys, A, col_perm] = local_make_systematic_encoder(H, K);

%% 5. 信息比特分块 + 末尾补 0
Nb = length(bin_stream);
% mod(K - mod(Nb,K), K)：把长度补到 K 的整数倍（若已整除则补 0）
n_pad_info = mod(K - mod(Nb, K), K);
info_padded = [bin_stream, zeros(1, n_pad_info)];
n_blocks = length(info_padded) / K;

fprintf('\n===== 分块 =====\n');
fprintf('原始信息比特 Nb = %d\n', Nb);
fprintf('信息补零 n_pad_info = %d\n', n_pad_info);
fprintf('码块数 n_blocks = %d\n', n_blocks);

%% 6. 逐块 LDPC 编码
coded_bits = zeros(1, n_blocks * N);
syndrome_ok = true(1, n_blocks);

for b = 1:n_blocks
    u = info_padded((b-1)*K + (1:K));         % 1 x K  本块信息位
    p = mod(A * u.', 2).';                   % 1 x Mparity  校验位
    c = [u, p];                               % 1 x N  系统码字 [u | p]
    coded_bits((b-1)*N + (1:N)) = c;

    % 自检：H_sys * c'' 应为全 0（GF(2) 下成立才说明编码正确）
    s = mod(H_sys * c.', 2);
    syndrome_ok(b) = all(s == 0);
end

fprintf('\n===== 编码结果 =====\n');
fprintf('编码比特总数 = %d (= n_blocks * N)\n', length(coded_bits));
fprintf('所有码字校验 H_sys*c=0 ? %s\n', string(all(syndrome_ok)));

u1 = info_padded(1:K);
c1 = coded_bits(1:N);
fprintf('第1块: 信息位前16bit = %s\n', sprintf('%d', u1(1:16)));
fprintf('第1块: 码字前16bit   = %s (系统码前K位应与信息位相同)\n', sprintf('%d', c1(1:16)));
fprintf('第1块: 校验位前16bit = %s\n', sprintf('%d', c1(K+1:K+16)));

%% 7. 保存（步骤3 用 coded_bits；步骤5 译码用 H_sys, N, K, n_pad_info 等）
save('step1b_ldpc_result.mat', 'N', 'K', 'R', 'wc', 'wr', 'H', 'H_sys', 'A', ...
     'col_perm', 'bin_stream', 'info_padded', 'n_pad_info', 'n_blocks', ...
     'coded_bits', 'syndrome_ok', 'Nb');
disp('已保存: step1b_ldpc_result.mat');

%% 8. 内置正确性校验（跑完自动验证，无需手工核对）
fprintf('\n===== 内置校验 =====\n');
H_perm = H(:, col_perm);
perm_ok = true;
for b = 1:n_blocks
    c = coded_bits((b-1)*N + (1:N)).';
    perm_ok = perm_ok && all(mod(H_perm * c, 2) == 0);
end
rec_info = [];
for b = 1:n_blocks
    rec_info = [rec_info, coded_bits((b-1)*N + (1:K))]; %#ok<AGROW>
end
info_ok   = isequal(rec_info, info_padded);
orig_ok   = isequal(rec_info(1:Nb), bin_stream);
pad_ok    = all(rec_info(Nb+1:end) == 0);
rank_ok   = (rank(H) == Mparity);

fprintf('H 满秩 (rank=%d)           : %s\n', rank(H), string(rank_ok));
fprintf('H_perm * c = 0 (全部码块)  : %s\n', string(perm_ok));
fprintf('码字前K位还原 info_padded  : %s\n', string(info_ok));
fprintf('还原前 Nb 位 = 原 bin_stream: %s\n', string(orig_ok));
fprintf('补零位全为 0               : %s\n', string(pad_ok));

if ~(all(syndrome_ok) && perm_ok && info_ok && orig_ok && pad_ok && rank_ok)
    warning('校验未全部通过，请检查 rng 或 LDPC 参数。');
else
    fprintf('>> 全部校验通过，可进入步骤3 OOK 调制。\n');
end

%% ===== 本地函数 =====
function H = local_make_regular_H(N, Mparity, wc, wr)
% 插座配对法构造近似规则 (wc, wr) 的 H
    n_edge = N * wc;
    var_socks = kron(1:N, ones(1, wc));
    chk_socks = kron(1:Mparity, ones(1, wr));
    chk_socks = chk_socks(randperm(n_edge));

    H = zeros(Mparity, N);
    for e = 1:n_edge
        H(chk_socks(e), var_socks(e)) = 1;
    end

    % 修补全 0 列/行，避免矩阵退化
    for j = 1:N
        if all(H(:, j) == 0)
            H(randi(Mparity), j) = 1;
        end
    end
    for i = 1:Mparity
        if all(H(i, :) == 0)
            H(i, randi(N)) = 1;
        end
    end
end

function [H_sys, A, col_perm] = local_make_systematic_encoder(H, K)
% GF(2) 消元 → 列置换 → H_sys = [A, I]，系统码字 c = [u, p]
    [Mparity, N] = size(H);
    if K ~= N - Mparity
        error('K 必须等于 N - size(H,1)');
    end

    Htmp = H;
    pivot_cols = zeros(1, Mparity);
    used = false(1, N);

    for row = 1:Mparity
        found = false;
        for c = 1:N
            if used(c), continue; end
            piv = find(Htmp(row:Mparity, c) == 1, 1, 'first');
            if isempty(piv), continue; end

            pr = row + piv - 1;
            if pr ~= row
                Htmp([row pr], :) = Htmp([pr row], :);
            end
            for r = 1:Mparity
                if r ~= row && Htmp(r, c) == 1
                    Htmp(r, :) = mod(Htmp(r, :) + Htmp(row, :), 2);
                end
            end
            pivot_cols(row) = c;
            used(c) = true;
            found = true;
            break;
        end
        if ~found
            error('H不满秩，无法系统编码。请修改 rng 种子后重跑。');
        end
    end

    info_cols = find(~used);
    if numel(info_cols) ~= K
        error('信息列数量不等于K，构造失败');
    end

    col_perm = [info_cols, pivot_cols];
    H_perm = H(:, col_perm);
    Hu = H_perm(:, 1:K);
    Hp = H_perm(:, K+1:N);

    Hp_inv = local_gf2_inv(Hp);
    A = mod(Hp_inv * Hu, 2);
    H_sys = [A, eye(Mparity)];
end

function Minv = local_gf2_inv(M)
% GF(2) 方阵求逆（高斯-约当）
    n = size(M, 1);
    if size(M, 2) ~= n
        error('只能对方阵求逆');
    end
    Aug = [M, eye(n)];
    for col = 1:n
        piv = find(Aug(col:n, col) == 1, 1, 'first');
        if isempty(piv)
            error('校验子矩阵不可逆，请修改 rng 种子后重跑');
        end
        pr = col + piv - 1;
        if pr ~= col
            Aug([col pr], :) = Aug([pr col], :);
        end
        for r = 1:n
            if r ~= col && Aug(r, col) == 1
                Aug(r, :) = mod(Aug(r, :) + Aug(col, :), 2);
            end
        end
    end
    Minv = Aug(:, n+1:end);
end
