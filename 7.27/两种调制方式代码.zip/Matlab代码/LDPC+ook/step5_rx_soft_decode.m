%% step5_rx_soft_decode.m
%==========================================================================
%  步骤五(软判决版)：接收端  软解调 + LDPC软译码  →  文本还原
%  (与 step5_rx_demod_decode.m 独立，不修改原文件)
%--------------------------------------------------------------------------
%  与硬判决版的区别：
%    - 不做硬判决门限比较，全程使用软值(窗均值)
%    - LLR 用 BPSK/OOK 在 AWGN 下的精确公式: LLR = (2/σ²) * (soft - μ)
%      其中 μ=(μ1+μ0)/2 是高低电平中点
%    - 译码采用全消息传递(BP/NMS)，不做 bit-flip
%    - 最终比特判决来自译码器输出，而非解调硬判
%--------------------------------------------------------------------------
%  输入文件：
%    (1) 示波器导出的 CSV  : scope_1_1.csv   (通道1，模拟电压 Volt)
%    (2) 前四步的 .mat 结果：
%        step1_result.mat         -> text_str, ascii_dec, bin_stream
%        step1b_ldpc_result.mat   -> H, H_sys, col_perm, K, N,
%                                    n_blocks, n_pad_info, info_padded, coded_bits
%        step3_result.mat         -> preamble_bits, tx_bits, T_slot
%        step4_uwoc_result.mat    -> N_sym_export, samples_per_symbol, fs
%
%  整体流程：
%    读CSV -> 估计示波器采样率 -> 前导帧同步 -> 符号定时抽取 -> 软值提取
%          -> 前导辅助估计 μ1,μ0,σ² -> 精确LLR -> LDPC NMS译码 -> 文本还原
%==========================================================================
clear; clc; close all;

%% ---------------- 关键参数 ----------------
csv_file     = 'scope_1_1.csv';     % 示波器通道1 CSV
csv_file_ext = 'scope_1_EXT.csv';   % 外触发通道(可选)

% --- LDPC 译码参数 ---
n_iter    = 50;        % BP 最大迭代次数
ms_factor = 0.75;      % 归一化最小和因子

% --- 耦合模式 ---
% AC耦合时，需要对 v_scope 做 movmean 去基线；DC耦合设为 false
is_ac_coupled = false;  % DC耦合=false; AC耦合=true

% --- AC耦合基线补偿(仅 is_ac_coupled=true 时生效) ---
baseline_lag = 2;       % 滞后符号数做本地基线差分
%% -------------------------------------------------------------------------

%% ===================== 0. 载入前四步结果 =====================
disp('>> 载入前四步结果 ...');
load('step1_result.mat',        'text_str','ascii_dec','bin_stream');
load('step1b_ldpc_result.mat',  'H','H_sys','col_perm','K','N', ...
                                'n_blocks','n_pad_info','info_padded','coded_bits');
load('step3_result.mat',        'preamble_bits','tx_bits','T_slot');
load('step4_uwoc_result.mat',   'N_sym_export','samples_per_symbol','fs');

preamble_bits = preamble_bits(:).';
tx_bits       = tx_bits(:).';
col_perm      = col_perm(:).';
coded_bits    = coded_bits(:).';
info_padded   = info_padded(:).';
H             = double(H) > 0.5;
H_sys         = double(H_sys) > 0.5;

fprintf('  LDPC: K=%d, N=%d, n_blocks=%d, n_pad_info=%d, R=%.2f\n', ...
        K, N, n_blocks, n_pad_info, K/N);
fprintf('  前导长度=%d, 发端导出符号数=%d\n', numel(preamble_bits), N_sym_export);

%% ===================== 1. 读取示波器 CSV =====================
disp('>> 读取示波器 CSV ...');
try
    M = readmatrix(csv_file, 'NumHeaderLines', 2);
catch
    M = dlmread(csv_file, ',', 2, 0);
end
t_scope = M(:,1);
v_scope = M(:,2);
N_pts = numel(v_scope);
fprintf('  CSV: %d 点, 时间 [%.4e, %.4e] s\n', N_pts, t_scope(1), t_scope(end));

%% ===================== 2. 估计示波器采样率 =====================
dt_scope = mean(diff(t_scope));
fs_scope = 1/dt_scope;
sps      = T_slot * fs_scope;
fprintf('  示波器 dt=%.2f ns, fs_scope=%.4f MHz\n', dt_scope*1e9, fs_scope/1e6);
fprintf('  每符号采样点 sps = %.4f (非整数)\n', sps);

search_coarse = round(sps/2);   % 粗搜索步长

%% ===================== 3. 前导帧同步 =====================
disp('>> 前导帧同步 (前导互相关) ...');

% 根据耦合模式选择是否去基线
if is_ac_coupled
    W_base = round(4*sps);
    v_sync = v_scope - movmean(v_scope, W_base);
    fprintf('  AC耦合模式：已做 movmean 去基线 (窗宽=%d 样本)\n', W_base);
else
    v_sync = v_scope;  % DC耦合：直接使用原始电压
    fprintf('  DC耦合模式：使用原始电压\n');
end

% 前导 ±1 模板 + 前缀和加速
pmb = 2*double(preamble_bits) - 1;
nP  = numel(preamble_bits);
cs  = [0; cumsum(v_sync(:))];
winmean = @(a0,a1) (cs(a1+1)-cs(a0))/(a1-a0+1);

% 粗搜索：步长 search_coarse，用 abs() 匹配(适应极性翻转)
best_c = -inf; best_start = round(sps);
for s0 = 1:search_coarse:(N_pts - round(nP*sps))
    vals = zeros(1,nP); ok = true;
    for k = 1:nP
        a0 = round(s0 + (k-1)*sps); a1 = round(s0 + k*sps);
        if a1 > N_pts || a0 < 1, ok=false; break; end
        vals(k) = winmean(a0,a1);
    end
    if ok
        c = abs(sum(vals .* pmb));
        if c > best_c, best_c = c; best_start = s0; end
    end
end

% 细搜索：粗结果附近 ±sps 逐样本精修
for d = -ceil(sps):ceil(sps)
    s = best_start + d;
    if s < 1, continue; end
    vals = zeros(1,nP); ok = true;
    for k = 1:nP
        a0 = round(s + (k-1)*sps); a1 = round(s + k*sps);
        if a1 > N_pts, ok=false; break; end
        vals(k) = winmean(a0,a1);
    end
    if ok
        c = abs(sum(vals .* pmb));
        if c > best_c, best_c = c; best_start = s; end
    end
end
frame_start = best_start;

% 极性判断
val_pre = zeros(1,nP);
for k = 1:nP
    a0 = round(frame_start + (k-1)*sps); a1 = round(frame_start + k*sps);
    if a1 > N_pts, val_pre = val_pre(1:k-1); break; end
    val_pre(k) = winmean(a0,a1);
end
pol = sign(mean(val_pre(preamble_bits==1)) - mean(val_pre(preamble_bits==0)));
if pol == 0, pol = 1; end
fprintf('  帧起始样本 = %d (t=%.5f ms), 前导极性 = %+d\n', ...
        frame_start, t_scope(frame_start)*1e3, pol);

%% ===================== 4. 逐符号软值提取 =====================
disp('>> 逐符号软值提取 ...');
n_sym_avail = floor((N_pts - frame_start)/sps);
n_sym = min(n_sym_avail, N_sym_export);
fprintf('  可用符号数 = %d (发端导出 %d)\n', n_sym, N_sym_export);

soft = zeros(1, n_sym);
for k = 1:n_sym
    a0 = round(frame_start + (k-1)*sps);
    a1 = round(frame_start +  k   *sps);
    if a1 > N_pts, soft = soft(1:k-1); n_sym = k-1; break; end
    soft(k) = winmean(a0,a1);
end
soft = soft * pol;   % 极性归一化：bit=1 对应更大软值

% AC耦合基线补偿
if is_ac_coupled && baseline_lag > 0
    base = [soft(1:baseline_lag), soft(1:end-baseline_lag)];
    soft = soft - base;
    fprintf('  AC基线补偿: lag=%d\n', baseline_lag);
end

%% ===================== 5. 前导辅助信道参数估计(软判决核心) =====================
disp('>> 前导辅助信道参数估计 ...');
% 利用已知前导位，分别估计 bit=1 和 bit=0 时软值的均值与方差。
% 这是软判决与硬判决的根本区别：不做硬判门限，而是用概率模型。

pre_soft = soft(1:nP);   % 前导段的软值

% 按发送比特分组
soft1 = pre_soft(preamble_bits == 1);  % 发 bit=1 时接收到的软值
soft0 = pre_soft(preamble_bits == 0);  % 发 bit=0 时接收到的软值

mu1 = mean(soft1);      % bit=1 的软值均值
mu0 = mean(soft0);      % bit=0 的软值均值
var1 = var(soft1);      % bit=1 的软值方差
var0 = var(soft0);      % bit=0 的软值方差

% 噪声方差：取两簇方差的平均(假设等方差 AWGN)
sigma2 = (var1 + var0) / 2;
if sigma2 <= 0
    sigma2 = var(soft);  % 降级：用全体方差
end
if sigma2 <= 0, sigma2 = 1e-6; end

fprintf('  μ1 = %.4f,  μ0 = %.4f,  间距 = %.4f\n', mu1, mu0, mu1-mu0);
fprintf('  σ² = %.6f,  σ  = %.4f\n', sigma2, sqrt(sigma2));

% 等效 SNR (仅参考)
snr_est = 10*log10((mu1-mu0)^2 / (4*sigma2));
fprintf('  估计 Eb/N0 ≈ %.2f dB\n', snr_est);

%% ===================== 6. 计算精确 LLR =====================
disp('>> 计算 LLR (BPSK/OOK AWGN 精确公式) ...');
% 对于 OOK，发送比特 b ∈ {0,1}，接收软值 y
% 假设 y|b=1 ~ N(μ1, σ²),  y|b=0 ~ N(μ0, σ²)
% LLR(b) = ln[ P(y|b=0) / P(y|b=1) ]
%        = ln[ exp(-(y-μ0)²/(2σ²)) / exp(-(y-μ1)²/(2σ²)) ]
%        = [ (y-μ1)² - (y-μ0)² ] / (2σ²)
%        = [ (μ0 - μ1)*(2y - μ0 - μ1) ] / (2σ²)
% 约定：LLR > 0 判 bit=0, LLR < 0 判 bit=1 (与 LDPC 译码器一致)

% 去掉前导，取数据段软值
data_soft = soft(nP+1:end);
n_data = numel(data_soft);
n_cw = floor(n_data / N);
fprintf('  数据位可用 = %d, 完整码字 = %d\n', n_data, n_cw);
data_soft = data_soft(1:n_cw*N);

% LLR 计算 (向量化)
% LLR = ((mu0 - mu1) .* (2*data_soft - mu0 - mu1)) / (2*sigma2);
% 等价更稳定的形式：
mid = (mu0 + mu1) / 2;          % 高低电平中点
scale = (mu0 - mu1) / sigma2;   % 标度因子
llr_all = scale .* (data_soft - mid);   % LLR>0→判0, LLR<0→判1

fprintf('  LLR 范围: [%.2f, %.2f]\n', min(llr_all), max(llr_all));

%% ===================== 7. LDPC 归一化最小和(NMS)软译码 =====================
disp('>> LDPC NMS 软译码 ...');

% 预计算 H 的邻接表
[m_chk, n_var] = size(H);
cn2vn = cell(m_chk,1);
vn2cn = cell(n_var,1);
for i = 1:m_chk
    cn2vn{i} = find(H(i,:));
end
for j = 1:n_var
    vn2cn{j} = find(H(:,j));
end

% 自检：稀疏H对已知码字 syndrome 全0
chk_ok = true;
for b = 1:n_blocks
    cb = coded_bits((b-1)*N+1:b*N);
    xb = zeros(1,N); xb(col_perm) = cb;
    if any(mod(H*xb.',2)), chk_ok = false; end
end
fprintf('  自检：稀疏H syndrome 全0? %d\n', chk_ok);

% 逐码字译码
rx_bits_dec = zeros(1, n_cw*N);
info_dec    = zeros(1, n_cw*K);
cw_status   = false(1, n_cw);
cw_iter     = zeros(1, n_cw);
llr_aposteriori = zeros(1, n_cw*N);   % 译码后的后验LLR(软输出)

for cw = 1:n_cw
    % 取当前码字的 LLR (系统序)
    llr_sys = llr_all((cw-1)*N+1 : cw*N);

    % 置换到稀疏H序：x(col_perm)=c → llr_sp(col_perm)=llr_sys
    llr_sp = zeros(1, N);
    llr_sp(col_perm) = llr_sys;

    % 初始化消息
    Mv2c = repmat(llr_sp, m_chk, 1);   % 128×256
    Mc2v = zeros(m_chk, N);
    L    = llr_sp;                      % 后验 LLR 初值

    for it = 1:n_iter
        % ---- (1) 校验节点 → 变量节点 (最小和) ----
        for i = 1:m_chk
            js = cn2vn{i};
            mv = Mv2c(i, js);
            sv = sign(mv); sv(mv==0) = 1;
            sgn_all = prod(sv);
            am = abs(mv);
            [mm, idx] = min(am);
            am_rest = am; am_rest(idx) = [];
            mm2 = min(am_rest);
            for qi = 1:numel(js)
                j = js(qi);
                ext = mm2 * (qi==idx) + mm * (qi~=idx);
                Mc2v(i,j) = ms_factor * (sgn_all / sv(qi)) * ext;
            end
        end

        % ---- (2) 变量节点 → 校验节点 ----
        colsum = sum(Mc2v, 1);
        L = llr_sp + colsum;            % 后验 LLR
        for j = 1:n_var
            for ii = vn2cn{j}
                Mv2c(ii,j) = llr_sp(j) + colsum(j) - Mc2v(ii,j);
            end
        end

        % ---- (3) 早停检测 ----
        x_hat = double(L < 0);
        syn = mod(H * x_hat.', 2);
        if ~any(syn)
            cw_status(cw) = true;
            cw_iter(cw) = it;
            break;
        end
    end

    if ~cw_status(cw)
        cw_iter(cw) = n_iter;
        % 最后一次硬判(即使未收敛)
        x_hat = double(L < 0);
        syn = mod(H * x_hat.', 2);
    end

    % 置换回系统序
    c_hat = x_hat(col_perm);
    rx_bits_dec((cw-1)*N+1:cw*N) = c_hat;
    info_dec((cw-1)*K+1:cw*K)   = c_hat(1:K);

    % 保存后验 LLR (系统序)
    llr_aposteriori((cw-1)*N+1:cw*N) = L(col_perm);

    if cw_status(cw)
        fprintf('  码字 %d: 收敛 @ 迭代%d\n', cw, cw_iter(cw));
    else
        fprintf('  码字 %d: 未收敛 (迭代%d, syndrome重量=%d)\n', ...
                cw, n_iter, sum(syn));
    end
end

%% ===================== 8. BER 统计(与发端比对，仅实验评估用) =====================
disp('>> BER 统计 ...');

% 软判决硬判(仅用于对比)：LLR>0 → bit0, LLR<0 → bit1
% 注意：llr_all 是系统序，直接与 coded_bits 比对即可
cmp_len_llr = min(n_cw*N, numel(coded_bits));
hard_from_llr = double(llr_all(1:cmp_len_llr) < 0);   % LLR<0 → bit1
ber_soft_demod = sum(hard_from_llr ~= coded_bits(1:cmp_len_llr)) / cmp_len_llr;

% 译码后 BER
cmp_len_dec = min(n_cw*N, numel(coded_bits));
ber_after_decode = sum(rx_bits_dec(1:cmp_len_dec) ~= coded_bits(1:cmp_len_dec)) / cmp_len_dec;

% 信息位 BER
cmp_len_info = min(n_cw*K, numel(info_padded));
ber_info = sum(info_dec(1:cmp_len_info) ~= info_padded(1:cmp_len_info)) / cmp_len_info;

fprintf('  软解调后 BER (LLR硬判) = %.4f%%\n', ber_soft_demod*100);
fprintf('  LDPC译码后 BER           = %.4f%%\n', ber_after_decode*100);
fprintf('  信息位 BER               = %.4f%%\n', ber_info*100);
fprintf('  成功译码码字: %d / %d\n', sum(cw_status), n_cw);
fprintf('  平均迭代次数: %.1f\n', mean(cw_iter));

%% ===================== 9. 文本还原 =====================
disp('>> 文本还原 ...');
n_info_have = n_cw * K;
if n_info_have >= (n_blocks*K - n_pad_info)
    n_real = n_blocks*K - n_pad_info;
    n_real = min(n_real, n_info_have);
else
    n_real = n_info_have;
end
real_info = info_dec(1:n_real);
n_byte = floor(numel(real_info)/8);
if n_byte > 0
    B = reshape(real_info(1:n_byte*8), 8, n_byte).';
    weights = 2.^(7:-1:0);
    ascii_dec_rx = uint8(B * weights.');
    text_rx = char(ascii_dec_rx);
else
    text_rx = '';
end

%% ===================== 结果展示 =====================
fprintf('\n==================== 软判决结果 ====================\n');
fprintf('帧起始样本        : %d\n', frame_start);
fprintf('每符号采样点      : %.4f\n', sps);
fprintf('信道估计 μ1       : %.4f V\n', mu1);
fprintf('信道估计 μ0       : %.4f V\n', mu0);
fprintf('噪声方差 σ²       : %.6f\n', sigma2);
fprintf('等效 Eb/N0        : %.2f dB\n', snr_est);
fprintf('软解调 BER        : %.4f%%\n', ber_soft_demod*100);
fprintf('LDPC译码后 BER    : %.4f%%\n', ber_after_decode*100);
fprintf('信息位 BER        : %.4f%%\n', ber_info*100);
fprintf('可用码字数        : %d / %d\n', n_cw, n_blocks);
fprintf('成功译码码字      : %d\n', sum(cw_status));
fprintf('平均迭代次数      : %.1f\n', mean(cw_iter));
fprintf('还原字符数        : %d\n', numel(text_rx));

if numel(text_rx) > 0
    ref_len = min(numel(text_rx), numel(text_str));
    fprintf('\n--- 原始文本(前 %d 字符) ---\n%s\n', ref_len, char(text_str(1:ref_len)));
    fprintf('\n--- 接收还原文本 ---\n%s\n', text_rx);
    char_match = sum(text_rx(1:ref_len) == text_str(1:ref_len)') / ref_len * 100;
    fprintf('字符一致率 = %.2f%%\n', char_match);
end

%% ===================== 可视化 =====================
figure('Name','步骤五(软判决) 接收解调译码');

% 子图1：原始波形 + 帧起始标记
subplot(4,1,1);
plot(t_scope*1e3, v_scope, 'b'); hold on;
xline(t_scope(frame_start)*1e3, 'r--', '帧起始');
title('示波器原始波形'); xlabel('时间 (ms)'); ylabel('电压 (V)'); grid on;

% 子图2：软值 + 高低电平均值线
subplot(4,1,2);
plot(1:n_sym, soft, '.-', 'MarkerSize', 3); hold on;
yline(mu1, 'r--', sprintf('μ1=%.3f', mu1));
yline(mu0, 'g--', sprintf('μ0=%.3f', mu0));
yline((mu1+mu0)/2, 'k:', '中点');
title(sprintf('逐符号软值 (软解调BER=%.2f%%)', ber_soft_demod*100));
xlabel('符号序号'); ylabel('软值'); grid on;

% 子图3：LLR 分布
subplot(4,1,3);
histogram(llr_all, 50, 'FaceColor', [0.2 0.4 0.8]);
xline(0, 'r--', 'LLR=0');
title(sprintf('LLR 分布 (σ²=%.4f)', sigma2));
xlabel('LLR'); ylabel('频次'); grid on;

% 子图4：各码字译码状态
subplot(4,1,4);
bar(1:n_cw, cw_iter, 'FaceColor', [0.3 0.7 0.3]); hold on;
plot(find(~cw_status), cw_iter(~cw_status), 'rx', 'MarkerSize', 12, 'LineWidth', 2);
yline(n_iter, 'r--', 'max iter');
title(sprintf('各码字迭代次数 (成功=%d/%d)', sum(cw_status), n_cw));
xlabel('码字序号'); ylabel('迭代次数'); grid on;
legend('收敛', '未收敛', 'Location', 'best');

%% ===================== 备份结果 =====================
save('step5_soft_result.mat', ...
     'frame_start','sps','fs_scope','mu1','mu0','sigma2','snr_est', ...
     'llr_all','llr_aposteriori','ber_soft_demod','ber_after_decode','ber_info', ...
     'n_cw','cw_status','cw_iter','info_dec','text_rx','rx_bits_dec');
fprintf('\n已保存 step5_soft_result.mat\n');
