%% step1_ascii_encode.m
% 步骤1：文本 -> 十进制ASCII字节流 -> 8位二进制字节流
%
% 【本步作用】
%   把要发送的字符串，先变成每个字符对应的 ASCII 十进制数，
%   再变成 0/1 比特流，供步骤2（LDPC编码）使用。
%
% 【不确定/可改参数】
%   text_str — 要发送的原始文本（本脚本默认 0~99 空格分隔）
%              改这里即可换发送内容；后续步骤会读 step1_result.mat，无需同步改变量名
%
% 【输出变量（后续步骤会 load 这些名字，请勿改名）】
%   text_str   — 原始字符串
%   ascii_dec  — 十进制 ASCII 数组，1×N
%   bin_mat    — 二进制矩阵，N×8，每行 1 个字节（MSB 在左）
%   bin_stream — 展平后的比特流，1×(N×8)

clear; clc;

%% 1. 原始文本
% 用 char 数组拼接长字符串；数字、空格各自占 1 个 ASCII 字节
% 例如 "10" 是字符 '1' 和 '0'，不是数值 10
text_str = ['0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 ' ...
            '26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 ' ...
            '50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 ' ...
            '74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 ' ...
            '98 99'];

%% 2. 文本 -> 十进制 ASCII 码字节流
% double(字符) 得到 0~255 的十进制码；普通英文字符/数字/空格在 0~127
ascii_dec = double(text_str);   % 1×N

%% 3. 十进制 ASCII -> 8 位二进制字节流
N = length(ascii_dec);          % 字符个数，后面 LDPC 分块会用到原始比特长度
bin_mat = zeros(N, 8);          % 每行 1 个字节，共 8 位

for i = 1:N
    % bitget(x, 8:-1:1)：从最高位到最低位取 8 位（MSB first）
    % 原因：通信里通常按“高位在前”排列比特，与 step5 还原一致
    bin_mat(i, :) = bitget(ascii_dec(i), 8:-1:1);
end

% 按列优先展平：第1字节的8位 → 第2字节的8位 → …
% reshape(..., 1, []) 得到 1×(N*8) 的 bin_stream，供 step1b_ldpc_encode 读取
bin_stream = reshape(bin_mat.', 1, []);

%% 4. 结果展示（前 10 个字符，便于手工核对）
disp('===== 核对示例（前10个字符）=====');
for i = 1:min(10, N)
    fprintf('字符: ''%s'' | 十进制ASCII: %3d | 8位二进制: %s\n', ...
        text_str(i), ascii_dec(i), num2str(bin_mat(i, :)));
end

fprintf('\n总字符数 N = %d\n', N);
fprintf('十进制ASCII字节流长度 = %d\n', length(ascii_dec));
fprintf('二进制比特流长度 = %d (应等于 N*8 = %d)\n', length(bin_stream), N*8);

%% 5. 保存结果，供步骤2（LDPC编码）使用
% 文件名 step1_result.mat 与 step1b_ldpc_encode.m 中的 load 对应，请勿改
save('step1_result.mat', 'text_str', 'ascii_dec', 'bin_mat', 'bin_stream');
disp('已保存: step1_result.mat');
