%% 步骤6：addNoiseWave文件夹多段CSV -> 合并统计误码率
% 输入：addNoiseWave/*.csv（细采样、单段约2ms，与addNoise.csv同类）
% 参考：step1b_ldpc_result.mat 中 coded_bits / H_sys / info_padded
% 说明：AWG通常循环前400符号(=800编码比特)；每段独立同步/解调/对齐后累加误码

clear; clc;

%% 0. 路径与参考数据
wave_dir = 'addNoiseWave';
if ~exist(wave_dir, 'dir')
    error('未找到文件夹: %s', wave_dir);
end
if ~exist('step1b_ldpc_result.mat', 'file')
    error('未找到 step1b_ldpc_result.mat');
end
if ~exist('step1_result.mat', 'file')
    error('未找到 step1_result.mat');
end

load('step1b_ldpc_result.mat', 'H_sys', 'N', 'K', 'coded_bits', 'info_padded');
load('step1_result.mat', 'text_str');

N_awg_bits = min(800, length(coded_bits));   % AWG导出前400符号
coded_ref = coded_bits(1:N_awg_bits);
cw_starts_in_awg = 1:N:N_awg_bits;
cw_starts_in_awg = cw_starts_in_awg((cw_starts_in_awg + N - 1) <= N_awg_bits);

files = dir(fullfile(wave_dir, '*.csv'));
if isempty(files)
    error('文件夹 %s 中没有CSV', wave_dir);
end
% 按文件名排序，保证 0,1,2,... 顺序稳定
[~, ord] = sort({files.name});
files = files(ord);

fprintf('===== 批量误码率计算 =====\n');
fprintf('文件夹: %s | 文件数: %d\n', wave_dir, numel(files));
fprintf('LDPC N=%d K=%d | AWG参考比特=%d | AWG内完整码字种类=%d\n', ...
    N, K, N_awg_bits, numel(cw_starts_in_awg));

%% 1. 累加器
sum_bits_ppm = 0; sum_err_ppm = 0;
sum_bits_cw  = 0; sum_err_cw_before = 0; sum_err_cw_after = 0;
sum_bits_info = 0; sum_err_info = 0;
sum_cw_ok = 0; sum_cw = 0;

per_file = struct('name', {}, 'dt_ns', {}, 'ber_ppm', {}, 'ber_cw_before', {}, ...
    'ber_cw_after', {}, 'ber_info', {}, 'n_cw', {}, 'n_cw_ok', {});

Mppm = 4;
T_slot = 1e-6;
T_sym = Mppm * T_slot;
max_iter = 50;

%% 2. 逐文件处理
for fidx = 1:numel(files)
    csv_name = fullfile(wave_dir, files(fidx).name);
    fprintf('\n----- [%d/%d] %s -----\n', fidx, numel(files), files(fidx).name);

    [t, v] = local_read_scope_csv(csv_name);
    dt = median(diff(t));
    fprintf('点数=%d, dt=%.3fns, 时长=%.3fms, V=[%.3f, %.3f]\n', ...
        numel(t), dt*1e9, (t(end)-t(1))*1e3, min(v), max(v));

    % 预处理：两种极性都试，选“与AWG参考对齐一致率”更高者
    thr_hi = (min(v) + max(v)) / 2;
    x_pos = double(v > thr_hi);
    v_flip = -v;
    thr_lo = (min(v_flip) + max(v_flip)) / 2;
    x_neg = double(v_flip > thr_lo);

    cand = {x_neg, x_pos};
    cand_name = {'低电平=脉冲(翻转)', '高电平=脉冲'};
    best_pol = 1;
    best_pol_score = -inf;
    pol_cache = struct();

    for pi = 1:2
        x_try = cand{pi};
        t_rel = t - t(1);
        n_grid = 32;   % 极性初选用较稀网格加速
        t0_list = linspace(0, T_sym, n_grid+1); t0_list(end) = [];
        score = zeros(1, n_grid);
        for ii = 1:n_grid
            [~, metric] = local_demod_ppm_fast(t_rel, x_try, dt, t0_list(ii), Mppm, T_slot, T_sym);
            if isempty(metric)
                score(ii) = -inf;
            else
                score(ii) = mean(metric);
            end
        end
        [sc, idx_best] = max(score);
        t0_hat = t0_list(idx_best);
        [pulse_pos_hat, ~, n_sym] = local_demod_ppm_fast(t_rel, x_try, dt, t0_hat, Mppm, T_slot, T_sym);
        bit_hat = zeros(1, n_sym*2);
        for k = 1:n_sym
            p = pulse_pos_hat(k);
            bit_hat(2*k-1) = floor(p/2);
            bit_hat(2*k) = mod(p, 2);
        end
        % 粗对齐得分
        Lmin = min(N, N_awg_bits);
        max_rx = min(400, max(0, numel(bit_hat)-Lmin));
        max_tx = max(0, N_awg_bits-Lmin);
        agree_best = -1; br=0; bt=0; bL=0;
        for tx0 = 0:2:max_tx
            for rx0 = 0:2:max_rx
                L = min(numel(bit_hat)-rx0, N_awg_bits-tx0);
                L = L - mod(L, 2);
                if L < Lmin, continue; end
                agree = mean(bit_hat(1+rx0:rx0+L) == coded_ref(1+tx0:tx0+L));
                if agree > agree_best
                    agree_best = agree; br=rx0; bt=tx0; bL=L;
                end
            end
        end
        pol_score = agree_best;
        if pol_score > best_pol_score
            best_pol_score = pol_score;
            best_pol = pi;
            pol_cache.x = x_try;
            pol_cache.t0_hat = t0_hat;
            pol_cache.bit_hat = bit_hat;
            pol_cache.best_rx = br;
            pol_cache.best_tx = bt;
            pol_cache.best_L = bL;
            pol_cache.best_agree = agree_best;
            pol_cache.best_score = sc;
            pol_cache.n_sym = n_sym;
        end
    end

    x = pol_cache.x;
    t0_hat = pol_cache.t0_hat;
    bit_hat = pol_cache.bit_hat;
    best_rx = pol_cache.best_rx;
    best_tx = pol_cache.best_tx;
    best_L = pol_cache.best_L;
    best_agree = pol_cache.best_agree;
    best_score = pol_cache.best_score;
    n_sym = pol_cache.n_sym;
    fprintf('极性: %s | 脉冲占比=%.2f%% | 粗对齐一致率=%.2f%%\n', ...
        cand_name{best_pol}, 100*mean(x), 100*best_agree);
    fprintf('t0=%.1fns, 同步得分=%.3f, 符号=%d, 解调比特=%d\n', ...
        t0_hat*1e9, best_score, n_sym, numel(bit_hat));

    % 用选定极性再做一次更细同步+对齐（64格）
    t_rel = t - t(1);
    n_grid = 64;
    t0_list = linspace(0, T_sym, n_grid+1); t0_list(end) = [];
    score = zeros(1, n_grid);
    for ii = 1:n_grid
        [~, metric] = local_demod_ppm_fast(t_rel, x, dt, t0_list(ii), Mppm, T_slot, T_sym);
        if isempty(metric)
            score(ii) = -inf;
        else
            score(ii) = mean(metric);
        end
    end
    [best_score, idx_best] = max(score);
    t0_hat = t0_list(idx_best);
    [pulse_pos_hat, ~, n_sym] = local_demod_ppm_fast(t_rel, x, dt, t0_hat, Mppm, T_slot, T_sym);
    bit_hat = zeros(1, n_sym*2);
    for k = 1:n_sym
        p = pulse_pos_hat(k);
        bit_hat(2*k-1) = floor(p/2);
        bit_hat(2*k) = mod(p, 2);
    end

    Lmin = min(N, N_awg_bits);
    max_rx = min(800, max(0, numel(bit_hat) - Lmin));
    max_tx = max(0, N_awg_bits - Lmin);
    best_agree = -1; best_rx = 0; best_tx = 0; best_L = 0;
    for tx0 = 0:2:max_tx
        for rx0 = 0:2:max_rx
            L = min(numel(bit_hat)-rx0, N_awg_bits-tx0);
            L = L - mod(L, 2);
            if L < Lmin, continue; end
            agree = mean(bit_hat(1+rx0:rx0+L) == coded_ref(1+tx0:tx0+L));
            if agree > best_agree
                best_agree = agree;
                best_rx = rx0; best_tx = tx0; best_L = L;
            end
        end
    end
    fprintf('精对齐: rx_lag=%d, tx_start=%d, L=%d, 一致率=%.2f%%\n', ...
        best_rx, best_tx, best_L, 100*best_agree);

    % 循环展开（AWG周期800bit）
    period_bits = N_awg_bits;
    rx_stream = bit_hat(1+best_rx:end);
    ref_cycle = [coded_ref(1+best_tx:end), coded_ref(1:best_tx)];
    n_rep = ceil(numel(rx_stream) / period_bits);
    ref_tile = repmat(ref_cycle, 1, n_rep);
    ref_tile = ref_tile(1:numel(rx_stream));
    L_use = numel(rx_stream) - mod(numel(rx_stream), 2);
    rx_use = rx_stream(1:L_use);
    ref_use = ref_tile(1:L_use);

    err_ppm = sum(rx_use ~= ref_use);
    sum_err_ppm = sum_err_ppm + err_ppm;
    sum_bits_ppm = sum_bits_ppm + L_use;
    ber_ppm_f = err_ppm / max(L_use, 1);

    % 收集完整码字（含多期重复）
    cw_rx_all = []; cw_ref_all = []; info_ref_all = [];
    for p0 = cw_starts_in_awg
        blk = floor((p0-1)/N) + 1;
        info_blk = info_padded((blk-1)*K + (1:K));
        target = mod(p0 - 1 - best_tx, period_bits);
        i0_list = (target + 1):period_bits:L_use;
        for i0 = i0_list
            if i0 + N - 1 <= L_use
                cw_rx_all = [cw_rx_all, rx_use(i0:i0+N-1)]; %#ok<AGROW>
                cw_ref_all = [cw_ref_all, coded_ref(p0:p0+N-1)]; %#ok<AGROW>
                info_ref_all = [info_ref_all, info_blk]; %#ok<AGROW>
            end
        end
    end

    n_cw = numel(cw_rx_all) / N;
    if n_cw < 1
        warning('文件 %s 未找到完整码字，跳过LDPC统计', files(fidx).name);
        per_file(fidx).name = files(fidx).name; %#ok<*SAGROW>
        per_file(fidx).dt_ns = dt*1e9;
        per_file(fidx).ber_ppm = ber_ppm_f;
        per_file(fidx).ber_cw_before = NaN;
        per_file(fidx).ber_cw_after = NaN;
        per_file(fidx).ber_info = NaN;
        per_file(fidx).n_cw = 0;
        per_file(fidx).n_cw_ok = 0;
        continue;
    end

    % LDPC硬判译码
    info_hat = zeros(1, n_cw*K);
    cw_hat = zeros(1, n_cw*N);
    ok_flags = false(1, n_cw);
    for b = 1:n_cw
        r = cw_rx_all((b-1)*N+(1:N));
        [c_hat, ok] = local_ldpc_bitflip(H_sys, r, max_iter);
        cw_hat((b-1)*N+(1:N)) = c_hat;
        info_hat((b-1)*K+(1:K)) = c_hat(1:K);
        ok_flags(b) = ok;
    end

    err_cw_b = sum(cw_rx_all ~= cw_ref_all);
    err_cw_a = sum(cw_hat ~= cw_ref_all);
    err_info = sum(info_hat ~= info_ref_all);
    bits_cw = numel(cw_ref_all);
    bits_info = numel(info_ref_all);

    sum_err_cw_before = sum_err_cw_before + err_cw_b;
    sum_err_cw_after  = sum_err_cw_after  + err_cw_a;
    sum_bits_cw = sum_bits_cw + bits_cw;
    sum_err_info = sum_err_info + err_info;
    sum_bits_info = sum_bits_info + bits_info;
    sum_cw_ok = sum_cw_ok + sum(ok_flags);
    sum_cw = sum_cw + n_cw;

    ber_cw_b_f = err_cw_b / bits_cw;
    ber_cw_a_f = err_cw_a / bits_cw;
    ber_info_f = err_info / bits_info;

    fprintf('码字 %d | 成功 %d | BER_ppm=%.3e | BER_cw前=%.3e | BER_cw后=%.3e | BER_info=%.3e\n', ...
        n_cw, sum(ok_flags), ber_ppm_f, ber_cw_b_f, ber_cw_a_f, ber_info_f);

    per_file(fidx).name = files(fidx).name;
    per_file(fidx).dt_ns = dt*1e9;
    per_file(fidx).ber_ppm = ber_ppm_f;
    per_file(fidx).ber_cw_before = ber_cw_b_f;
    per_file(fidx).ber_cw_after = ber_cw_a_f;
    per_file(fidx).ber_info = ber_info_f;
    per_file(fidx).n_cw = n_cw;
    per_file(fidx).n_cw_ok = sum(ok_flags);
end

%% 3. 合并总误码率
ber_ppm = sum_err_ppm / max(sum_bits_ppm, 1);
ber_cw_before = sum_err_cw_before / max(sum_bits_cw, 1);
ber_cw_after  = sum_err_cw_after  / max(sum_bits_cw, 1);
ber_info = sum_err_info / max(sum_bits_info, 1);

fprintf('\n========== 合并误码率汇总 (addNoiseWave, %d文件) ==========\n', numel(files));
fprintf('PPM解调比特: 错误 %d / 总 %d\n', sum_err_ppm, sum_bits_ppm);
fprintf('完整码字比特: 错误前 %d / 后 %d / 总 %d | 成功码字 %d / %d\n', ...
    sum_err_cw_before, sum_err_cw_after, sum_bits_cw, sum_cw_ok, sum_cw);
fprintf('信息比特: 错误 %d / 总 %d\n', sum_err_info, sum_bits_info);
fprintf('1) 解调后/译码前 编码BER = %.6e\n', ber_ppm);
fprintf('2) 码字段译码前 编码BER = %.6e\n', ber_cw_before);
fprintf('3) 码字段译码后 编码BER = %.6e\n', ber_cw_after);
fprintf('4) 信息比特BER         = %.6e\n', ber_info);
fprintf('5) 码字译码成功率       = %.2f%%\n', 100*sum_cw_ok/max(sum_cw,1));
fprintf('==========================================================\n');

save('step6_ber_addNoise_result.mat', 'wave_dir', 'files', 'per_file', ...
     'ber_ppm', 'ber_cw_before', 'ber_cw_after', 'ber_info', ...
     'sum_err_ppm', 'sum_bits_ppm', 'sum_err_cw_before', 'sum_err_cw_after', ...
     'sum_bits_cw', 'sum_err_info', 'sum_bits_info', 'sum_cw_ok', 'sum_cw', ...
     'N', 'K', 'N_awg_bits');
disp('已保存: step6_ber_addNoise_result.mat');

%% ===== 本地函数 =====
function [t, v] = local_read_scope_csv(csv_name)
    fid = fopen(csv_name, 'r');
    if fid < 0, error('无法打开 %s', csv_name); end
    fgetl(fid); fgetl(fid);
    C = textscan(fid, '%f%f', 'Delimiter', ',');
    fclose(fid);
    t = C{1}(:).';
    v = C{2}(:).';
end

function [pulse_pos, metric, n_sym] = local_demod_ppm_fast(t_rel, x, dt, t0, M, T_slot, T_sym)
% 用采样下标累加时隙能量，避免反复逻辑索引（细采样时更快）
    n_sym = floor((t_rel(end) - t0) / T_sym);
    if n_sym < 1
        pulse_pos = []; metric = []; return;
    end
    pulse_pos = zeros(n_sym, 1);
    metric = zeros(n_sym, 1);
    n = numel(x);
    for k = 0:n_sym-1
        e = zeros(1, M);
        for m = 0:M-1
            ta = t0 + k*T_sym + m*T_slot;
            tb = ta + T_slot;
            i1 = floor((ta - t_rel(1)) / dt) + 1;
            i2 = floor((tb - t_rel(1)) / dt);
            i1 = max(1, i1); i2 = min(n, i2);
            if i2 >= i1
                e(m+1) = sum(x(i1:i2));
            end
        end
        [emax, imax] = max(e);
        pulse_pos(k+1) = imax - 1;
        metric(k+1) = emax - (sum(e) - emax) / max(M-1, 1);
    end
end

function [c_hat, ok] = local_ldpc_bitflip(H, r, max_iter)
    c = r(:).';
    for it = 1:max_iter
        s = mod(H * c.', 2);
        if all(s == 0)
            break;
        end
        fail_cnt = s.' * H;
        fmax = max(fail_cnt);
        if fmax <= 0, break; end
        flip_idx = find(fail_cnt == fmax);
        c(flip_idx) = 1 - c(flip_idx);
    end
    ok = all(mod(H * c.', 2) == 0);
    c_hat = c;
end
