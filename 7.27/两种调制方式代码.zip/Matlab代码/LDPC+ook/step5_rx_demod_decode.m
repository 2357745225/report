%% step5_rx_demod_decode.m
%==========================================================================
%  步骤五：接收端  解调 + LDPC译码  →  文本还原
%  (v2.1: 修复DC耦合下movmean破坏同步的bug, 改用原始电压做前导搜索)
%--------------------------------------------------------------------------
%  输入文件：
%    (1) 示波器导出的 CSV  : scope_1_1.csv   (通道1，模拟电压 Volt)
%                            scope_1_EXT.csv (外触发通道，本步骤可选/仅作参考)
%    (2) 前四步的 .mat 结果(保持原变量名，不改动)：
%        step1_result.mat         -> text_str, ascii_dec, bin_stream
%        step1b_ldpc_result.mat   -> H, H_sys, col_perm, K, N,
%                                    n_blocks, n_pad_info, info_padded, coded_bits
%        step3_result.mat         -> preamble_bits, tx_bits, T_slot
%        step4_uwoc_result.mat    -> N_sym_export, samples_per_symbol, fs
%
%  整体流程：
%    读CSV -> 估计示波器采样率 -> 前导帧同步(原始电压) -> 符号定时抽取 -> OOK软解调
%          -> 计算LLR -> LDPC最小和译码 -> 去填充 -> 二进制转ASCII
%  
%  v2.1 修复说明:
%    - 原代码对 v_scope 做 movmean 去基线后搜索前导，DC耦合下这会破坏信号
%      电平结构，导致帧同步偏移~39样本，前导BER从1.56%飙到97%，整段BER~50%
%    - 改为直接对原始电压 v_scope 做前导搜索和窗均值解调
%    - AC耦合采集时，取消第97行 v_sync = v_scope 的注释，改为去基线版本
%    - 噪声方差改为用前导两簇各自方差取平均，比全局判0更稳
%==========================================================================
clear; clc; close all;

%% ---------------- 关键参数(不确定处已注明，可按你的实际硬件修改) ----------------
csv_file   = 'scope_1_1.csv';   % 示波器通道1(模拟电压)的CSV文件名
csv_file_ext = 'scope_1_EXT.csv';% 外触发/参考通道(本程序只读取、不强制使用)

% --- LDPC 译码参数 ---
n_iter     = 50;        % BP(置信传播)最大迭代次数；50次一般够，码长较短可再加大
ms_factor  = 0.75;      % 归一化最小和因子(0.7~0.8常用，比纯最小和更准)；不确定就保持0.75

% --- 接收端基线补偿参数(针对AC耦合基线漂移，实验确定) ---
baseline_lag = 0;       % 用“滞后 baseline_lag 个符号”的软值做本地基线；
                        % 实测 baseline_lag=2 时数据段BER最低(见文末说明)。
                        % 若你的采集链路是DC耦合，可设为 0 关闭基线补偿。

% --- 帧同步搜索范围(样本数)---
% 示波器记录起点不一定是信号起点，需在前导附近搜索。这里给一个较宽范围。
% search_coarse 在 sps 计算后定义(见第2节末尾)，这里暂不赋值。
%% -------------------------------------------------------------------------

%% ===================== 0. 载入前四步结果(不改变量名) =====================
disp('>> 载入前四步结果 ...');
load('step1_result.mat',        'text_str','ascii_dec','bin_stream');
load('step1b_ldpc_result.mat',  'H','H_sys','col_perm','K','N', ...
                                'n_blocks','n_pad_info','info_padded','coded_bits');
load('step3_result.mat',        'preamble_bits','tx_bits','T_slot');
load('step4_uwoc_result.mat',   'N_sym_export','samples_per_symbol','fs');

% 取成行向量(便于索引)
preamble_bits = preamble_bits(:).';
tx_bits       = tx_bits(:).';
col_perm      = col_perm(:).';
coded_bits    = coded_bits(:).';
info_padded   = info_padded(:).';
H             = double(H);          % 128x256 稀疏校验矩阵(用于BP译码)
H_sys         = double(H_sys);      % 128x256 系统型(仅作对照，本程序译码用稀疏H)

% 将校验矩阵限定为 0/1
H     = (H     > 0.5);
H_sys = (H_sys > 0.5);

fprintf('  LDPC: K=%d, N=%d, n_blocks=%d, n_pad_info=%d, R=%.2f\n', ...
        K, N, n_blocks, n_pad_info, K/N);
fprintf('  前导长度=%d, 实际导出(发端)符号数 N_sym_export=%d\n', ...
        numel(preamble_bits), N_sym_export);

%% ===================== 1. 读取示波器 CSV =====================
disp('>> 读取示波器 CSV ...');
% 该CSV前两行是表头：第1行 "x-axis,1"，第2行 "second,Volt"，之后是两列数值。
% 用 readmatrix 跳过前2行表头，自动解析科学计数法与前置空格。
try
    M = readmatrix(csv_file, 'NumHeaderLines', 2);
catch
    % 兼容老版本MATLAB：用 dlmread 跳过2行
    M = dlmread(csv_file, ',', 2, 0);
end
t_scope = M(:,1);          % 时间轴 (秒)
v_scope = M(:,2);          % 电压   (伏)
N_pts = numel(v_scope);
fprintf('  CSV: %d 点, 时间 [%.4e, %.4e] s\n', N_pts, t_scope(1), t_scope(end));

%% ===================== 2. 估计示波器采样率 =====================
% 从时间轴直接算 dt，不要直接相信标称值——实测更可靠。
dt_scope  = mean(diff(t_scope));
fs_scope  = 1/dt_scope;
sps       = T_slot * fs_scope;     % ★ 每符号的示波器采样点数(非整数!)
fprintf('  示波器 dt=%.2f ns, fs_scope=%.4f MHz\n', dt_scope*1e9, fs_scope/1e6);
fprintf('  每符号采样点 sps = T_slot*fs_scope = %.4f  (注意：非整数!)\n', sps);

% 帧同步粗搜索步长（sps 已算好，在此定义）
search_coarse = round(sps/2);  % 粗搜索步长，取半个符号周期的样本数

% 提示：sps 非整数会导致"按整数下标切分"累计漂移，因此下面用 round() 逐符号取窗，
%       并在前导处做一次精确同步，足以覆盖全部 ~1250 个符号而不发散。

%% ===================== 3. 前导帧同步(在原始电压上做互相关) =====================
disp('>> 前导帧同步 (前导互相关) ...');
% 注意：DC耦合下不应做 movmean 去基线！那会人为破坏信号电平结构，
%       导致同步失败(前导BER~97%, 整段BER~50%)。AC耦合时才需要去基线。
% 直接对原始电压 v_scope 做前导搜索。
v_sync = v_scope;  % DC耦合：直接用原始信号；AC耦合时改为 v_scope - movmean(...)

% 3.1 用 ±1 前导模板在前导长度×sps 的窗口内对齐
%     为加速，用累加和(cumsum)实现 O(1) 任意窗口求均值。
pmb = 2*double(preamble_bits) - 1;   % 前导 ±1 模板 (1100 -> +1,+1,-1,-1)
nP   = numel(preamble_bits);
cs   = [0; cumsum(v_sync(:))];       % 前缀和, cs(k+1)=sum(v_sync(1:k))
winmean = @(a0,a1) (cs(a1+1)-cs(a0))/(a1-a0+1);  % v_sync(a0:a1) 的均值

% 粗搜索(步长 search_coarse)。用 abs(c) 而非 c，因为信号极性可能翻转
% (bit=1 对应高电平还是低电平在搜索阶段未知，用绝对值找到最强匹配位置即可)
best_c = -inf; best_start = round(sps);
for s0 = 1:search_coarse:(N_pts - round(nP*sps))
    vals = zeros(1,nP);
    ok = true;
    for k = 1:nP
        a0 = round(s0 + (k-1)*sps); a1 = round(s0 + k*sps);
        if a1 > N_pts || a0 < 1, ok=false; break; end
        vals(k) = winmean(a0,a1);
    end
    if ok
        c = abs(sum(vals .* pmb));     % 用绝对值！信号极性可能翻转
        if c > best_c, best_c = c; best_start = s0; end
    end
end

% 细搜索：在粗结果附近 ±sps 逐样本精修
for d = -ceil(sps):ceil(sps)
    s = best_start + d;
    if s < 1, continue; end
    vals = zeros(1,nP); ok = true;
    for k = 1:nP
        a0 = round(s + (k-1)*sps); a1 = round(s + k*sps);
        if a1 > N_pts, ok=false; break; end
        vals(k) = winmean(a0,a1);
    end
    if ok
        c = abs(sum(vals .* pmb));     % 用绝对值！
        if c > best_c, best_c = c; best_start = s; end
    end
end
frame_start = best_start;

% 极性判断：前导位=1 处软值应更高；若相反则后续翻转。
val_pre = zeros(1,nP);
for k = 1:nP
    a0 = round(frame_start + (k-1)*sps); a1 = round(frame_start + k*sps);
    if a1 > N_pts, val_pre = val_pre(1:k-1); break; end
    val_pre(k) = winmean(a0,a1);
end
pol = sign(mean(val_pre(preamble_bits==1)) - mean(val_pre(preamble_bits==0)));
if pol == 0, pol = 1; end
fprintf('  帧起始样本 = %d (t=%.5f ms), 前导极性 = %+d\n', ...
        frame_start, t_scope(frame_start)*1e3, pol);

%% ===================== 4. OOK 软解调(逐符号取窗均值) =====================
disp('>> 逐符号软解调 ...');
% 计算可切出的符号数(受示波器记录长度限制)
n_sym_avail = floor((N_pts - frame_start)/sps);
n_sym = min(n_sym_avail, N_sym_export);   % 不超过发端实际导出的符号数
fprintf('  可用符号数 = %d (发端导出 %d)\n', n_sym, N_sym_export);

soft = zeros(1, n_sym);
for k = 1:n_sym
    a0 = round(frame_start + (k-1)*sps);
    a1 = round(frame_start +  k   *sps);
    if a1 > N_pts, soft = soft(1:k-1); n_sym = k-1; break; end
    soft(k) = winmean(a0,a1);
end
soft = soft * pol;     % 极性归一化：保证 bit=1 对应软值更大

% --- AC耦合基线补偿(lead-lag 差分)：减去滞后若干符号的本地基线 ---
%     实测 baseline_lag=2 时数据段 BER 最低(见文末说明)。
if baseline_lag > 0
    base = [soft(1:baseline_lag), soft(1:end-baseline_lag)];  % 滞后基线(边界用自身填充)
    soft = soft - base;
end

% --- 自适应阈值：用软值“高/低”两簇均值的中点 ---
%     这里用 1/0 各自的样本均值估计阈值(用前导已知位辅助，更稳)
hi = soft(preamble_bits==1);   lo = soft(preamble_bits==0);
thr = 0.5*(mean(hi) + mean(lo));
hard_rx = double(soft > thr);             % 硬判决(>thr -> 1)

% --- 与发端比对 BER(发端已知，仅用于本实验评估，真实接收端无此步) ---
cmp_len = min(n_sym, numel(tx_bits));
ber_all = sum(hard_rx(1:cmp_len) ~= tx_bits(1:cmp_len)) / cmp_len;
ber_pre = sum(hard_rx(1:min(nP,cmp_len)) ~= tx_bits(1:min(nP,cmp_len))) / min(nP,cmp_len);
fprintf('  整段硬判决 BER = %.2f%%   (前导段 BER = %.2f%%)\n', ber_all*100, ber_pre*100);

%% ===================== 5. 计算 LLR + LDPC 最小和译码 =====================
disp('>> LDPC 最小和译码 ...');
% 5.1 去掉前导，取数据段软值
data_soft = soft(nP+1:end);
n_data = numel(data_soft);
n_cw = floor(n_data / N);                 % 能凑出的完整码字数
fprintf('  数据位可用 = %d, 完整码字 = %d\n', n_data, n_cw);
data_soft = data_soft(1:n_cw*N);

% 5.2 LLR：假设近似高斯。约定 LLR>0 判 bit0，LLR<0 判 bit1。
%     (因 soft 大 -> bit1，故 LLR = -(soft-thr)*2/σ²，使 bit1 对应 LLR<0)
% 噪声方差：用前导的 1/0 两簇各自方差取平均(比全局判0更稳)
mask1 = (soft(preamble_bits==1) > thr);
mask0 = (soft(preamble_bits==0) < thr);
var1 = var(soft(preamble_bits==1)); 
var0 = var(soft(preamble_bits==0));
sigma2 = (var1 + var0) / 2;
if isempty(sigma2) || sigma2 <= 0, sigma2 = var(data_soft); end
if sigma2 <= 0, sigma2 = 1; end
fprintf('  噪声方差估计 σ² = %.4f\n', sigma2);

% 5.3 预计算 H 的邻接表(加速BP)
[m_chk, n_var] = size(H);
cn2vn = cell(m_chk,1);     % 每个校验节点连接的变量节点列表
vn2cn = cell(n_var,1);
for i = 1:m_chk
    cn2vn{i} = find(H(i,:));
end
for j = 1:n_var
    vn2cn{j} = find(H(:,j));
end

% 列置换关系(已验证)：系统码字 c 满足 H_sys·c=0；
%   令 x(col_perm)=c (即 x 在 col_perm 指定位置取 c 的值)，则稀疏 H·x=0，
%   可直接对稀疏H做BP。译码后 c_hat = x_hat(col_perm)，取前 K 位为信息位。
% 下面做一个自检：对每个已知码字做置换后送入稀疏H，syndrome 应全0。
chk_ok = true;
for b = 1:n_blocks
    cb = coded_bits((b-1)*N+1:b*N);
    xb = zeros(1,N); xb(col_perm) = cb;        % 系统 -> 稀疏序
    if any(mod(H*xb.',2)), chk_ok = false; end
end
fprintf('  自检：稀疏H对%d个已知码字 syndrome 全0? %d\n', n_blocks, chk_ok);

% 5.4 逐码字译码 (标准并行/洪泛 归一化最小和 NMS)
%     消息约定：Mv2c(i,j) 变量->校验, Mc2v(i,j) 校验->变量, 初值 Mv2c=LLR
rx_bits_dec = zeros(1, n_cw*N);     % 译码后比特(系统码字序)
info_dec    = zeros(1, n_cw*K);     % 译码后信息位
cw_status   = false(1, n_cw);

for cw = 1:n_cw
    seg = data_soft((cw-1)*N+1 : cw*N);
    llr_sys = -(seg - thr) * 2 / sigma2;   % 系统序 LLR (bit1->LLR<0)

    % 置换到稀疏H序：x(col_perm)=c, 故 llr_sp(col_perm)=llr_sys
    llr_sp = zeros(1, N);
    llr_sp(col_perm) = llr_sys;

    % 初始化 var->check 消息 = 信道 LLR
    Mv2c = repmat(llr_sp, m_chk, 1);      % 128x256
    Mc2v = zeros(m_chk, N);
    x_hat = double(llr_sp < 0);           % 初始硬判
    it = n_iter;
    for it = 1:n_iter
        % ---- (1) 校验节点 -> 变量节点 (最小和) ----
        for i = 1:m_chk
            js = cn2vn{i};                       %该校验连接的变量下标
            mv  = Mv2c(i, js);                   %输入消息
            sv  = sign(mv); sv(mv==0) = 1;       %符号(零按+1)
            sgn_all = prod(sv);                  %全部符号之积
            am  = abs(mv);
            [mm, idx] = min(am);                %最小值及其位置
            % 次小值：去掉最小值后的最小
            am_rest = am; am_rest(idx) = [];
            mm2 = min(am_rest);
            for qi = 1:numel(js)
                j = js(qi);
                ext = mm2 * (qi==idx) + mm * (qi~=idx);  %自身最小用次小,否则用最小
                Mc2v(i,j) = ms_factor * (sgn_all / sv(qi)) * ext;  %其它符号=总符号/自身符号
            end
        end
        % ---- (2) 变量节点 -> 校验节点 ----
        colsum = sum(Mc2v, 1);           % 各变量收到的校验消息总和 (1xN)
        L = llr_sp + colsum;             % 后验 LLR
        for j = 1:n_var
            for ii = vn2cn{j}
                Mv2c(ii,j) = llr_sp(j) + colsum(j) - Mc2v(ii,j);  %外信息=总-自身
            end
        end
        % ---- (3) 硬判 + 早停 ----
        x_hat = double(L < 0);
        syn = mod(H * x_hat.', 2);
        if ~any(syn)
            cw_status(cw) = true; break;
        end
    end
    if cw_status(cw)
        fprintf('  码字 %d: 收敛 @ 迭代%d\n', cw, it);
    else
        fprintf('  码字 %d: 未收敛 (迭代%d, syndrome重量=%d)\n', cw, it, sum(syn));
    end
    % 置换回系统序并取信息位
    c_hat = x_hat(col_perm);
    rx_bits_dec((cw-1)*N+1:cw*N) = c_hat;
    info_dec((cw-1)*K+1:cw*K)   = c_hat(1:K);
end

%% ===================== 6. 去填充 + 二进制转ASCII -> 文本还原 =====================
disp('>> 文本还原 ...');
% 发端 info_padded = [真实信息 Nb=2312 位] + [末尾补零 n_pad_info=120 位] = 19*K = 2432 位。
% 补零只在“最后一个码字(第19个)”的尾部。本接收端通常只能译出前几个码字
% (本数据约 4 个)，不会触及补零区，故译出的信息位全部为真实信息。
% 为通用，按下式计算“真实信息”位数：
n_info_have = n_cw * K;                                  % 已译出的信息位总数
if n_info_have >= (n_blocks*K - n_pad_info)
    % 译到了含补零的最后一个码字：需把末尾 n_pad_info 位补零去掉
    n_real = n_blocks*K - n_pad_info;                    % = Nb，发端真实信息总长
    n_real = min(n_real, n_info_have);
else
    n_real = n_info_have;                                % 未触及补零区，全部为真实信息
end
real_info = info_dec(1:n_real);
n_byte = floor(numel(real_info)/8);
if n_byte > 0
    B = reshape(real_info(1:n_byte*8), 8, n_byte).';      % n_byte x 8 (每行一个字节, MSB在前)
    weights = 2.^(7:-1:0);                                % [128 64 32 ... 1]
    ascii_dec_rx = uint8(B * weights.');                  % 二进制 -> 十进制ASCII
    text_rx = char(ascii_dec_rx);
else
    text_rx = '';
end

%% ===================== 结果展示 =====================
fprintf('\n==================== 结果 ====================\n');
fprintf('帧起始样本      : %d\n', frame_start);
fprintf('每符号采样点    : %.4f (非整数)\n', sps);
fprintf('整段硬判 BER    : %.2f%%\n', ber_all*100);
fprintf('前导 BER        : %.2f%%\n', ber_pre*100);
fprintf('可用完整码字数  : %d / %d (发端共%d)\n', n_cw, n_blocks, n_blocks);
fprintf('成功译码码字    : %d\n', sum(cw_status));
fprintf('还原字符数      : %d\n', numel(text_rx));
fprintf('\n--- 原始文本(前 %d 字符) ---\n%s\n', numel(text_rx), char(text_str(1:numel(text_rx))));
fprintf('\n--- 接收还原文本 ---\n%s\n', text_rx);

% 可视化
figure('Name','步骤五 接收解调译码');
subplot(3,1,1);
plot(t_scope*1e3, v_scope, 'b'); hold on;
xline(t_scope(frame_start)*1e3,'r--','帧起始');
title('示波器原始波形'); xlabel('时间 (ms)'); ylabel('电压 (V)'); grid on;
subplot(3,1,2);
plot(1:n_sym, soft,'.-'); hold on; yline(thr,'r--','阈值');
title(sprintf('逐符号软值 (整段BER=%.2f%%)', ber_all*100));
xlabel('符号序号'); grid on;
subplot(3,1,3);
plot(1:n_cw, cw_status,'o','MarkerFaceColor','r'); ylim([-0.2 1.2]);
set(gca,'YTick',[0 1],'YTickLabel',{'失败','成功'});
title('各码字LDPC译码状态'); xlabel('码字序号'); grid on;

%% ===================== 备份结果 =====================
save('step5_result.mat','frame_start','sps','fs_scope','thr','ber_all','ber_pre', ...
     'n_cw','cw_status','info_dec','text_rx','rx_bits_dec');
fprintf('\n已保存 step5_result.mat\n');
fprintf('\n说明：本数据下若整段BER较高(>10%%)且码字未收敛，通常源于示波器\n');
fprintf('     AC耦合基线漂移 + 真实信道SNR不足，详见代码注释与回答中的建议。\n');
