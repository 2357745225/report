%% 步骤2：编码比特流 -> 4-PPM 调制（光通信基带）
% 参数（按你的设定）：
%   M = 4            每符号4个时隙
%   samples_per_slot = 10
%   矩形脉冲幅度 = 1
%   无保护间隔
%   映射：自然二进制  00->时隙0, 01->时隙1, 10->时隙2, 11->时隙3
%
% 注意：现在调制输入来自 LDPC 编码比特 coded_bits（步骤1b）
%       不再直接使用未编码的 bin_stream

clear; clc;

%% 1. 读取步骤1b的LDPC编码结果
if ~exist('step1b_ldpc_result.mat', 'file')
    error('未找到 step1b_ldpc_result.mat，请先运行 step1b_ldpc_encode.m');
end
load('step1b_ldpc_result.mat', 'coded_bits');   % 1 x Nc 的LDPC编码比特
bin_stream = coded_bits;                        % 后续变量名保持不变，少改代码

%% 2. PPM 参数
M = 4;                      % PPM阶数
bits_per_symbol = log2(M);  % = 2
samples_per_slot = 10;      % 每时隙采样点数
amp = 1;                    % 矩形脉冲幅度
samples_per_symbol = M * samples_per_slot;  % 无保护间隔：40

%% 3. 比特分组（每2比特 -> 1个PPM符号）
Nb = length(bin_stream);
pad_len = mod(bits_per_symbol - mod(Nb, bits_per_symbol), bits_per_symbol);
% 若不能整除，末尾补0（本次数据2312可被2整除，pad_len应为0）
bit_padded = [bin_stream, zeros(1, pad_len)];
Ns = length(bit_padded) / bits_per_symbol;   % 符号数

bit_groups = reshape(bit_padded, bits_per_symbol, Ns).';   % Ns x 2

% 比特组 -> 脉冲位置编号（0 ~ M-1）
% 例： [0 0]->0, [0 1]->1, [1 0]->2, [1 1]->3
pulse_pos = bit_groups(:,1) * 2 + bit_groups(:,2);   % Ns x 1，取值0~3

%% 4. 生成PPM基带波形（光强非负：选中时隙为1，其余为0）
ppm_signal = zeros(1, Ns * samples_per_symbol);

for k = 1:Ns
    sym_start = (k - 1) * samples_per_symbol + 1;
    slot_start = sym_start + pulse_pos(k) * samples_per_slot;
    slot_end   = slot_start + samples_per_slot - 1;
    ppm_signal(slot_start:slot_end) = amp;
end

%% 5. 核对示例（前5个符号）
disp('===== 4-PPM 核对示例（前5个符号）=====');
disp('映射规则: 00->时隙0, 01->时隙1, 10->时隙2, 11->时隙3');
for k = 1:5
    fprintf('符号% d | 比特: %d%d | 脉冲时隙: %d | 该符号波形(按时隙均值): ', ...
        k, bit_groups(k,1), bit_groups(k,2), pulse_pos(k));
    sym = ppm_signal((k-1)*samples_per_symbol + (1:samples_per_symbol));
    slot_mean = mean(reshape(sym, samples_per_slot, M), 1);
    disp(slot_mean);
end

fprintf('\n原始比特数 Nb = %d\n', Nb);
fprintf('补零位数 pad_len = %d\n', pad_len);
fprintf('PPM符号数 Ns = %d\n', Ns);
fprintf('每符号采样点 = %d\n', samples_per_symbol);
fprintf('PPM信号总长度 = %d\n', length(ppm_signal));

%% 6. 画前3个符号，便于直观理解
figure;
stem(ppm_signal(1:3*samples_per_symbol), 'filled', 'MarkerSize', 3);
xlabel('采样点');
ylabel('光强幅度');
title('4-PPM 基带波形（前3个符号）');
grid on;
xline(samples_per_symbol + 0.5, '--r');
xline(2*samples_per_symbol + 0.5, '--r');
legend('PPM信号', '符号分界', 'Location', 'best');

%% 7. 保存结果
save('step2_result.mat', 'M', 'bits_per_symbol', 'samples_per_slot', 'amp', ...
     'samples_per_symbol', 'bit_padded', 'pad_len', 'bit_groups', ...
     'pulse_pos', 'ppm_signal', 'Ns');
disp('已保存: step2_result.mat');
