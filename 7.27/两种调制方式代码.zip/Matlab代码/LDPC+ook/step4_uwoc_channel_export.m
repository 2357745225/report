%% step4_uwoc_channel_export.m
% 步骤4：水下光信道仿真，并导出 EasyWave CSV
% 适配步骤3 OOK 基带（读 step3_result.mat）
%
% 【信道模型 — 与你的 PAM 版相同】
%   发送基带 s(t) 经衰减：s_att = alpha * s
%   加 AWGN：y = max(s_att + n, 0)          （光强非负截断）
%   方案B 等效接收放大：z = max(G * y, 0)   （G=1/alpha，无噪时高电平回到约 1V）
%
% 【与 PAM 版的改动】
%   1) 输入改为 step3_result.mat 的 OOK 波形（0/1 两电平，非 4-PAM 四电平）
%   2) T_slot/dt/fs 优先从 step3 读取，保证与调制端时序一致
%   3) 输出 step4_uwoc_result.mat + OOK 专用 CSV 文件名
%
% 【不确定/可改参数】
%   alpha = 0.0136     杰罗夫 I 型海水、100 m 近似衰减系数 e^{-cL}
%   SNR_dB = 5         相对衰减后信号 s_att 的 AWGN 信噪比 (dB)
%   rng(42)            噪声随机种子，改数字可换一组噪声
%   N_sym_export=1600  导出符号数；×10 采样 = 16000 点（SDG 系列 16k 上限）
%   限幅 [0, 1.5] V    防止噪声尖峰损坏 AWG/示波器量程

clear; clc;
rng(42);    % 固定噪声种子，结果可复现

%% 1. 读取步骤3 OOK 波形
if ~exist('step3_result.mat', 'file')
    error('未找到 step3_result.mat，请先运行 step3_ook_modulate.m');
end
load('step3_result.mat', 'ppm_signal', 'ook_signal', 'samples_per_symbol', ...
     'samples_per_slot', 'Ns', 'T_slot', 'dt', 'fs', 'amp');

% s：发送端基带。OOK 仅 0 V / amp V 两电平（ppm_signal 与 ook_signal 相同）
s = ppm_signal(:).';

%% 2. 信道参数
alpha = 0.0136;                % 杰罗夫 I、100 m：alpha ≈ exp(-cL)
SNR_dB = 5;                    % AWGN 信噪比（相对 s_att 定义）
G = 1 / alpha;                 % 方案B：等效接收端增益，把无噪峰值拉回约 1 V
V_high = amp;                  % 与步骤3 高电平一致（默认 1 V）

% --- 衰减 ---
s_att = alpha * s;

% --- AWGN：噪声功率按衰减后信号功率 Ps 与 SNR 计算 ---
Ps = mean(s_att.^2);
SNR_lin = 10^(SNR_dB/10);
Pn = Ps / SNR_lin;
n = sqrt(Pn) * randn(size(s_att));

% --- 加噪 + 光强非负截断 ---
y = max(s_att + n, 0);

% --- 方案B：等效放大后再截断（上 AWG/示波器用的电压波形）---
z = max(G * y, 0);

% 实测 SNR（截断前线性域，更接近定义）
snr_check_dB = 10*log10(mean(s_att.^2) / mean(n.^2));

fprintf('===== 水下光信道仿真 (OOK) =====\n');
fprintf('发送 s: min=%.3f, max=%.3f, 占空比(≈1的比例)=%.1f%%\n', ...
    min(s), max(s), 100*mean(s > 0.5*max(s)));
fprintf('alpha = %.6f, SNR设定 = %.1f dB, 实测SNR = %.2f dB\n', ...
    alpha, SNR_dB, snr_check_dB);
fprintf('衰减后峰值约 = %.4f, 放大后无噪峰值约 = %.2f\n', alpha*max(s), max(s));
fprintf('z: min=%.3f, max=%.3f, mean=%.3f\n', min(z), max(z), mean(z));

%% 3. 导出到 EasyWave CSV
N_sym_export = 1600;   % 1600 符号 × 10 采样/符号 = 16000 点
if N_sym_export > Ns
    error('请求导出 %d 符号，但 OOK 波形只有 %d 符号。', N_sym_export, Ns);
end

N_pts = N_sym_export * samples_per_symbol;

% 时序参数：优先用 step3 保存的值，避免与调制端不一致
if ~exist('T_slot', 'var') || isempty(T_slot)
    T_slot = 1e-6;
end
if ~exist('dt', 'var') || isempty(dt)
    dt = T_slot / samples_per_slot;
end
if ~exist('fs', 'var') || isempty(fs)
    fs = 1 / dt;
end

wave = z(1:N_pts);
wave = min(max(wave, 0), 1.5);   % 限幅保护 AWG

T_period = N_pts * dt;
freq_hz = 1 / T_period;
amp_hdr = max(V_high, max(wave));
offset_hdr = 0;
phase_hdr = 0;
xpos = (0:N_pts-1) * dt;

out_name = sprintf('uwoc_OOK_jerlovI_100m_SNR%ddB_%dsym_EasyWave.csv', SNR_dB, N_sym_export);
fid = fopen(out_name, 'w');
if fid < 0
    error('无法创建: %s', out_name);
end
fprintf(fid, 'data length,%d\n', N_pts);
fprintf(fid, 'frequency,%.9f\n', freq_hz);
fprintf(fid, 'amp,%.9f\n', amp_hdr);
fprintf(fid, 'offset,%.9f\n', offset_hdr);
fprintf(fid, 'phase,%.9f\n', phase_hdr);
for k = 1:7
    fprintf(fid, ',\n');
end
fprintf(fid, 'xpos,value\n');
for i = 1:N_pts
    fprintf(fid, '%.6E,%.9f\n', xpos(i), wave(i));
end
fclose(fid);

fprintf('\n===== EasyWave CSV =====\n');
fprintf('文件: %s\n', out_name);
fprintf('点数=%d, 符号=%d, dt=%.3fus, fs=%.3fMSa/s\n', ...
    N_pts, N_sym_export, dt*1e6, fs/1e6);
fprintf('导出波形: min=%.3f V, max=%.3f V\n', min(wave), max(wave));
fprintf('【上机提示】EasyWaveX → File → Open → 选上述 CSV → 下载到 SDG 示波器/AFG\n');

%% 4. 画对比图（前 3 个 OOK 符号）
n_show = 3 * samples_per_symbol;
figure;
subplot(3,1,1);
stem(s(1:n_show), 'filled', 'MarkerSize', 2);
title('发送 OOK 基带 (s)'); ylabel('幅度 (V)'); grid on;
ylim([-0.1, max(s)+0.2]);
subplot(3,1,2);
plot(y(1:n_show));
title(sprintf('衰减+噪声 y=max(\\alpha s+n,0), \\alpha=%.4f, SNR=%d dB', alpha, SNR_dB));
ylabel('幅度'); grid on;
subplot(3,1,3);
plot(z(1:n_show));
title('方案B放大后 z（导出/上仪器）'); xlabel('采样点'); ylabel('V'); grid on;

%% 5. 内置校验
export_ok = (length(wave) == N_pts);
level_ok  = all(wave >= 0 & wave <= 1.5);
peak_ok   = (max(wave) <= 1.5 + 1e-9);
snr_ok    = abs(snr_check_dB - SNR_dB) < 3;   % 允许截断带来的小偏差

fprintf('\n===== 内置校验 =====\n');
fprintf('导出点数 = N_sym*spb      : %s\n', string(export_ok));
fprintf('波形在 [0, 1.5] V 内    : %s\n', string(level_ok));
fprintf('实测SNR 接近设定(±3dB) : %s (%.2f dB)\n', string(snr_ok), snr_check_dB);
if export_ok && level_ok && snr_ok
    fprintf('>> 步骤4完成。可将 CSV 导入 AWG，或用 z 做 MATLAB 纯仿真接收。\n');
end

%% 6. 保存（步骤5 可用 z/s/n 做纯仿真解调；上示波器则用 CSV 录回）
save('step4_uwoc_result.mat', 'alpha', 'SNR_dB', 'G', 's', 's_att', 'n', ...
     'y', 'z', 'wave', 'out_name', 'N_sym_export', 'N_pts', 'dt', 'fs', ...
     'T_slot', 'snr_check_dB', 'samples_per_symbol', 'samples_per_slot', 'Ns', ...
     'V_high', 'amp');
disp('已保存: step4_uwoc_result.mat');
