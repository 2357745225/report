%% 步骤7：addNoiseWave -> 4-PPM软解调(LLR) -> Min-Sum软译码 -> 合并误码率
% 按你的确认：
%   数据：addNoiseWave/*.csv
%   软信息：比特LLR（由4时隙能量 max-log 得到）
%   噪声方差：由波形空闲样点估计
%   译码：Min-Sum，最大迭代50
%   校验矩阵：step1b 中现有 H_sys

clear; clc;

%% 0. 路径与参考
wave_dir = 'addNoiseWave';
if ~exist(wave_dir, 'dir'), error('未找到 %s', wave_dir); end
if ~exist('step1b_ldpc_result.mat', 'file'), error('未找到 step1b_ldpc_result.mat'); end

load('step1b_ldpc_result.mat', 'H_sys', 'N', 'K', 'coded_bits', 'info_padded');

N_awg_bits = min(800, length(coded_bits));
coded_ref = coded_bits(1:N_awg_bits);
cw_starts_in_awg = 1:N:N_awg_bits;
cw_starts_in_awg = cw_starts_in_awg((cw_starts_in_awg + N - 1) <= N_awg_bits);

files = dir(fullfile(wave_dir, '*.csv'));
if isempty(files), error('无CSV'); end
[~, ord] = sort({files.name});
files = files(ord);

Mppm = 4;
T_slot = 1e-6;
T_sym = Mppm * T_slot;
max_iter = 50;

fprintf('===== 软判决批量误码率 =====\n');
fprintf('文件数=%d | N=%d K=%d | Min-Sum iter=%d | AWG参考比特=%d\n', ...
    numel(files), N, K, max_iter, N_awg_bits);

%% 累加器
sum_bits_ppm = 0; sum_err_ppm = 0;
sum_bits_cw = 0; sum_err_cw_before = 0; sum_err_cw_after = 0;
sum_bits_info = 0; sum_err_info = 0;
sum_cw_ok = 0; sum_cw = 0;
per_file = struct('name',{}, 'ber_ppm',{}, 'ber_cw_before',{}, 'ber_cw_after',{}, ...
    'ber_info',{}, 'n_cw',{}, 'n_cw_ok',{}, 'sigma2',{}, 'A',{});

%% 逐文件
for fidx = 1:numel(files)
    csv_name = fullfile(wave_dir, files(fidx).name);
    fprintf('\n----- [%d/%d] %s -----\n', fidx, numel(files), files(fidx).name);

    [t, v] = local_read_scope_csv(csv_name);
    dt = median(diff(t));
    t_rel = t - t(1);
    fprintf('点数=%d, dt=%.3fns, 时长=%.3fms\n', numel(t), dt*1e9, (t(end)-t(1))*1e3);

    % --- 极性选择：仍用硬判决对齐一致率（与step6相同思路）---
    [ys, pol_name, bit_hat, t0_hat, best_rx, best_tx, best_agree] = ...
        local_select_polarity_and_sync(t, v, dt, T_slot, T_sym, Mppm, coded_ref, N, N_awg_bits);
    fprintf('极性: %s | 对齐一致率=%.2f%% | t0=%.1fns\n', pol_name, 100*best_agree, t0_hat*1e9);

    % --- 噪声/幅度估计（波形空闲与脉冲样点）---
    thr = (min(ys) + max(ys)) / 2;
    idle = ys(ys <= thr);
    pulse = ys(ys > thr);
    if numel(idle) < 10 || numel(pulse) < 10
        warning('空闲/脉冲样点过少，改用全体方差估计');
        sigma2 = var(ys);
        A = max(ys) - mean(ys);
    else
        sigma2 = var(idle);                 % 样点噪声方差
        A = mean(pulse) - mean(idle);       % 脉冲相对空闲的幅度
    end
    sigma2 = max(sigma2, 1e-12);
    A = max(A, 1e-6);
    fprintf('波形估计: sigma2=%.4e, A=%.4f\n', sigma2, A);

    % --- 软解调：时隙能量 -> 比特LLR ---
    n_sym = floor((t_rel(end) - t0_hat) / T_sym);
    ns_slot = max(1, round(T_slot / dt));
    % 能量噪声方差（约 ns_slot 个独立样点之和）
    sigma2_E = sigma2 * ns_slot;
    scale = A / sigma2_E;                   % m_i ≈ scale * E_i  (正比于对数似然)

    llr_hat = zeros(1, n_sym*2);
    bit_hard = zeros(1, n_sym*2);
    for k = 0:n_sym-1
        E = zeros(1, Mppm);
        for m = 0:Mppm-1
            ta = t0_hat + k*T_sym + m*T_slot;
            tb = ta + T_slot;
            i1 = floor((ta - t_rel(1))/dt) + 1;
            i2 = floor((tb - t_rel(1))/dt);
            i1 = max(1, i1); i2 = min(numel(ys), i2);
            if i2 >= i1
                E(m+1) = sum(ys(i1:i2));
            end
        end
        met = scale * E;                    % 4个时隙度量
        % 映射: 时隙0->00,1->01,2->10,3->11 ；LLR>0更像比特0
        % bit1(MSB): 0对应时隙0/1, 1对应时隙2/3
        % bit0(LSB): 0对应时隙0/2, 1对应时隙1/3
        llr1 = max(met(1), met(2)) - max(met(3), met(4));
        llr0 = max(met(1), met(3)) - max(met(2), met(4));
        llr_hat(2*k+1) = llr1;
        llr_hat(2*k+2) = llr0;
        bit_hard(2*k+1) = double(llr1 < 0);
        bit_hard(2*k+2) = double(llr0 < 0);
    end

    % 用硬比特做帧对齐（更稳），LLR随同一套对齐参数抽取
    [best_rx, best_tx, best_L, best_agree2] = local_frame_align(bit_hard, coded_ref, N, N_awg_bits);
    fprintf('精对齐: rx=%d tx=%d L=%d 一致率=%.2f%%\n', best_rx, best_tx, best_L, 100*best_agree2);

    period_bits = N_awg_bits;
    rx_bits = bit_hard(1+best_rx:end);
    rx_llr  = llr_hat(1+best_rx:end);
    ref_cycle = [coded_ref(1+best_tx:end), coded_ref(1:best_tx)];
    n_rep = ceil(numel(rx_bits)/period_bits);
    ref_tile = repmat(ref_cycle, 1, n_rep);
    L_use = numel(rx_bits) - mod(numel(rx_bits), 2);
    rx_use = rx_bits(1:L_use);
    llr_use = rx_llr(1:L_use);
    ref_use = ref_tile(1:L_use);

    err_ppm = sum(rx_use ~= ref_use);
    sum_err_ppm = sum_err_ppm + err_ppm;
    sum_bits_ppm = sum_bits_ppm + L_use;
    ber_ppm_f = err_ppm / max(L_use,1);

    % 收集完整码字的硬比特/LLR/参考
    cw_rx_all = []; cw_ref_all = []; llr_all = []; info_ref_all = [];
    for p0 = cw_starts_in_awg
        blk = floor((p0-1)/N) + 1;
        info_blk = info_padded((blk-1)*K+(1:K));
        target = mod(p0-1-best_tx, period_bits);
        i0_list = (target+1):period_bits:L_use;
        for i0 = i0_list
            if i0+N-1 <= L_use
                cw_rx_all = [cw_rx_all, rx_use(i0:i0+N-1)]; %#ok<AGROW>
                cw_ref_all = [cw_ref_all, coded_ref(p0:p0+N-1)]; %#ok<AGROW>
                llr_all = [llr_all, llr_use(i0:i0+N-1)]; %#ok<AGROW>
                info_ref_all = [info_ref_all, info_blk]; %#ok<AGROW>
            end
        end
    end

    n_cw = numel(cw_rx_all)/N;
    if n_cw < 1
        warning('无完整码字，跳过');
        continue;
    end

    % Min-Sum 软译码
    info_hat = zeros(1, n_cw*K);
    cw_hat = zeros(1, n_cw*N);
    ok_flags = false(1, n_cw);
    for b = 1:n_cw
        Lch = llr_all((b-1)*N+(1:N));
        [c_hat, ok] = local_ldpc_minsum(H_sys, Lch, max_iter);
        cw_hat((b-1)*N+(1:N)) = c_hat;
        info_hat((b-1)*K+(1:K)) = c_hat(1:K);
        ok_flags(b) = ok;
    end

    err_b = sum(cw_rx_all ~= cw_ref_all);
    err_a = sum(cw_hat ~= cw_ref_all);
    err_i = sum(info_hat ~= info_ref_all);
    bits_cw = numel(cw_ref_all);
    bits_info = numel(info_ref_all);

    sum_err_cw_before = sum_err_cw_before + err_b;
    sum_err_cw_after = sum_err_cw_after + err_a;
    sum_bits_cw = sum_bits_cw + bits_cw;
    sum_err_info = sum_err_info + err_i;
    sum_bits_info = sum_bits_info + bits_info;
    sum_cw_ok = sum_cw_ok + sum(ok_flags);
    sum_cw = sum_cw + n_cw;

    fprintf('码字%d 成功%d | BER_ppm=%.3e | cw前=%.3e | cw后=%.3e | info=%.3e\n', ...
        n_cw, sum(ok_flags), ber_ppm_f, err_b/bits_cw, err_a/bits_cw, err_i/bits_info);

    per_file(fidx).name = files(fidx).name; %#ok<*SAGROW>
    per_file(fidx).ber_ppm = ber_ppm_f;
    per_file(fidx).ber_cw_before = err_b/bits_cw;
    per_file(fidx).ber_cw_after = err_a/bits_cw;
    per_file(fidx).ber_info = err_i/bits_info;
    per_file(fidx).n_cw = n_cw;
    per_file(fidx).n_cw_ok = sum(ok_flags);
    per_file(fidx).sigma2 = sigma2;
    per_file(fidx).A = A;
end

%% 汇总
ber_ppm = sum_err_ppm/max(sum_bits_ppm,1);
ber_cw_before = sum_err_cw_before/max(sum_bits_cw,1);
ber_cw_after = sum_err_cw_after/max(sum_bits_cw,1);
ber_info = sum_err_info/max(sum_bits_info,1);

fprintf('\n========== 软判决合并误码率 (addNoiseWave) ==========\n');
fprintf('PPM解调比特: 错误 %d / 总 %d\n', sum_err_ppm, sum_bits_ppm);
fprintf('完整码字比特: 译码前错 %d / 后错 %d / 总 %d | 成功码字 %d / %d\n', ...
    sum_err_cw_before, sum_err_cw_after, sum_bits_cw, sum_cw_ok, sum_cw);
fprintf('信息比特: 错误 %d / 总 %d\n', sum_err_info, sum_bits_info);
fprintf('1) 解调后/译码前 编码BER = %.6e\n', ber_ppm);
fprintf('2) 码字段译码前 编码BER = %.6e\n', ber_cw_before);
fprintf('3) 码字段译码后 编码BER = %.6e\n', ber_cw_after);
fprintf('4) 信息比特BER         = %.6e\n', ber_info);
fprintf('5) 码字译码成功率       = %.2f%%\n', 100*sum_cw_ok/max(sum_cw,1));
fprintf('====================================================\n');

save('step7_ber_soft_result.mat', 'wave_dir', 'files', 'per_file', ...
    'ber_ppm', 'ber_cw_before', 'ber_cw_after', 'ber_info', ...
    'sum_err_ppm', 'sum_bits_ppm', 'sum_err_cw_before', 'sum_err_cw_after', ...
    'sum_bits_cw', 'sum_err_info', 'sum_bits_info', 'sum_cw_ok', 'sum_cw', ...
    'max_iter', 'N', 'K', 'N_awg_bits');
disp('已保存: step7_ber_soft_result.mat');

%% ===== 本地函数 =====
function [t, v] = local_read_scope_csv(csv_name)
    fid = fopen(csv_name, 'r');
    fgetl(fid); fgetl(fid);
    C = textscan(fid, '%f%f', 'Delimiter', ',');
    fclose(fid);
    t = C{1}(:).'; v = C{2}(:).';
end

function [pulse_pos, metric, n_sym] = local_demod_ppm_fast(t_rel, x, dt, t0, M, T_slot, T_sym)
    n_sym = floor((t_rel(end)-t0)/T_sym);
    if n_sym < 1, pulse_pos=[]; metric=[]; return; end
    pulse_pos = zeros(n_sym,1); metric = zeros(n_sym,1); n=numel(x);
    for k=0:n_sym-1
        e=zeros(1,M);
        for m=0:M-1
            ta=t0+k*T_sym+m*T_slot; tb=ta+T_slot;
            i1=floor((ta-t_rel(1))/dt)+1; i2=floor((tb-t_rel(1))/dt);
            i1=max(1,i1); i2=min(n,i2);
            if i2>=i1, e(m+1)=sum(x(i1:i2)); end
        end
        [emax,imax]=max(e);
        pulse_pos(k+1)=imax-1;
        metric(k+1)=emax-(sum(e)-emax)/max(M-1,1);
    end
end

function [best_rx, best_tx, best_L, best_agree] = local_frame_align(bit_hat, coded_ref, N, N_awg_bits)
    Lmin = min(N, N_awg_bits);
    max_rx = min(800, max(0, numel(bit_hat)-Lmin));
    max_tx = max(0, N_awg_bits-Lmin);
    best_agree=-1; best_rx=0; best_tx=0; best_L=0;
    for tx0=0:2:max_tx
        for rx0=0:2:max_rx
            L=min(numel(bit_hat)-rx0, N_awg_bits-tx0); L=L-mod(L,2);
            if L<Lmin, continue; end
            agree=mean(bit_hat(1+rx0:rx0+L)==coded_ref(1+tx0:tx0+L));
            if agree>best_agree
                best_agree=agree; best_rx=rx0; best_tx=tx0; best_L=L;
            end
        end
    end
end

function [ys, pol_name, bit_hat, t0_hat, best_rx, best_tx, best_agree] = ...
    local_select_polarity_and_sync(t, v, dt, T_slot, T_sym, Mppm, coded_ref, N, N_awg_bits)
    t_rel = t - t(1);
    thr_hi = (min(v)+max(v))/2;
    x_pos = double(v > thr_hi);
    v_flip = -v;
    thr_lo = (min(v_flip)+max(v_flip))/2;
    x_neg = double(v_flip > thr_lo);
    cand_x = {x_neg, x_pos};
    cand_ys = {v_flip, v};
    cand_name = {'低电平=脉冲(翻转)', '高电平=脉冲'};

    best_pol = 1; best_agree = -inf;
    cache = struct();
    for pi = 1:2
        x = cand_x{pi};
        n_grid = 32;
        t0_list = linspace(0, T_sym, n_grid+1); t0_list(end)=[];
        score = zeros(1,n_grid);
        for ii=1:n_grid
            [~, metric] = local_demod_ppm_fast(t_rel, x, dt, t0_list(ii), Mppm, T_slot, T_sym);
            if isempty(metric), score(ii)=-inf; else, score(ii)=mean(metric); end
        end
        [~, idx] = max(score);
        t0 = t0_list(idx);
        [pos, ~, n_sym] = local_demod_ppm_fast(t_rel, x, dt, t0, Mppm, T_slot, T_sym);
        bh = zeros(1,n_sym*2);
        for k=1:n_sym
            p=pos(k); bh(2*k-1)=floor(p/2); bh(2*k)=mod(p,2);
        end
        [br, bt, bL, ag] = local_frame_align(bh, coded_ref, N, N_awg_bits);
        if ag > best_agree
            best_agree = ag; best_pol = pi;
            cache.t0 = t0; cache.bit_hat = bh; cache.br=br; cache.bt=bt;
        end
    end
    % 细同步
    x = cand_x{best_pol};
    ys = cand_ys{best_pol};
    n_grid = 64;
    t0_list = linspace(0, T_sym, n_grid+1); t0_list(end)=[];
    score = zeros(1,n_grid);
    for ii=1:n_grid
        [~, metric] = local_demod_ppm_fast(t_rel, x, dt, t0_list(ii), Mppm, T_slot, T_sym);
        if isempty(metric), score(ii)=-inf; else, score(ii)=mean(metric); end
    end
    [~, idx] = max(score);
    t0_hat = t0_list(idx);
    [pos, ~, n_sym] = local_demod_ppm_fast(t_rel, x, dt, t0_hat, Mppm, T_slot, T_sym);
    bit_hat = zeros(1,n_sym*2);
    for k=1:n_sym
        p=pos(k); bit_hat(2*k-1)=floor(p/2); bit_hat(2*k)=mod(p,2);
    end
    [best_rx, best_tx, ~, best_agree] = local_frame_align(bit_hat, coded_ref, N, N_awg_bits);
    pol_name = cand_name{best_pol};
end

function [c_hat, ok] = local_ldpc_minsum(H, Lch, max_iter)
% Min-Sum 置信传播（flooding）
    [M, Nn] = size(H);
    Lch = Lch(:).';
    % 边列表
    [chk, var] = find(H);
    E = numel(chk);
    % 校验->变量 消息 R，初值0
    R = zeros(1, E);
    % 预存每个校验/变量的边下标
    chk_edges = cell(M,1);
    var_edges = cell(Nn,1);
    for e = 1:E
        chk_edges{chk(e)}(end+1) = e; %#ok<*AGROW>
        var_edges{var(e)}(end+1) = e;
    end

    Lapp = Lch;
    for it = 1:max_iter
        % 变量->校验 消息 Q
        Q = zeros(1, E);
        for n = 1:Nn
            eds = var_edges{n};
            if isempty(eds), continue; end
            for ii = 1:numel(eds)
                e = eds(ii);
                Q(e) = Lch(n) + sum(R(eds)) - R(e);
            end
        end
        % 校验->变量 Min-Sum
        for m = 1:M
            eds = chk_edges{m};
            if isempty(eds), continue; end
            qq = Q(eds);
            sgn = sign(qq); sgn(sgn==0) = 1;
            aq = abs(qq);
            for ii = 1:numel(eds)
                % 除自身外的最小绝对值
                mask = true(1, numel(eds)); mask(ii)=false;
                if ~any(mask)
                    R(eds(ii)) = 0;
                else
                    min1 = min(aq(mask));
                    R(eds(ii)) = prod(sgn(mask)) * min1;
                end
            end
        end
        % APP
        for n = 1:Nn
            eds = var_edges{n};
            Lapp(n) = Lch(n) + sum(R(eds));
        end
        c_hat = double(Lapp < 0);
        s = mod(H * c_hat.', 2);
        if all(s==0)
            ok = true;
            return;
        end
    end
    c_hat = double(Lapp < 0);
    ok = all(mod(H * c_hat.', 2) == 0);
end
